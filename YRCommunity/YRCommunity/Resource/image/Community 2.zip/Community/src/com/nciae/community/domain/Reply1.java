package com.nciae.community.domain;

public class Reply1 extends Reply{
	private String memName;

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}
	

}
