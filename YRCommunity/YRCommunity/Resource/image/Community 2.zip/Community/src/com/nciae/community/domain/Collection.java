package com.nciae.community.domain;

public class Collection {

	private Integer id;
	private Integer memId;
	private Integer shopperId;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getMemId() {
		return memId;
	}
	public void setMemId(Integer memId) {
		this.memId = memId;
	}
	public Integer getShopperId() {
		return shopperId;
	}
	public void setShopperId(Integer shopperId) {
		this.shopperId = shopperId;
	}
}
