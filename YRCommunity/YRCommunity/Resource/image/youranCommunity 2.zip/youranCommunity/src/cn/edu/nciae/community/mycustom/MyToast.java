package cn.edu.nciae.community.mycustom;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.personal.R;

public class MyToast {

	// �Զ���Toast,����ʱֱ��new ����(context,title,cecondText)
	public Toast toast;
	private final LayoutInflater inflater;

	public MyToast(Context context, String titleText, String secondText,
			int time) {

		inflater = LayoutInflater.from(context);

		View view = inflater.inflate(R.layout.mytoast_layout, null);

		TextView title = (TextView) view
				.findViewById(R.id.mytoast_layout_title);
		title.setText(titleText);

		TextView text = (TextView) view.findViewById(R.id.mytoast_layout_tv);
		text.setText(secondText);

		toast = new Toast(context);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setDuration(time);
		toast.setView(view);
		toast.show();
	}
}
