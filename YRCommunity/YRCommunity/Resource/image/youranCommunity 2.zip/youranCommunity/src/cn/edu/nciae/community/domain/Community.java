package cn.edu.nciae.community.domain;


public class Community {// С����
	private Integer id;
	
	private String remark;
	private Byte isActive;// С���Ƿ���� 0 ������ 1 ���� Ĭ��1
	private Integer cityId;
	private Integer likeCount;// ���޸���-----ͬ�⿪ͨ�ĸ���
	private Byte opened;// С�� ��ͨ״̬ 0 δ��ͨ 1 �ѿ�ͨ
	private String realName;//��ҵ����
	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getShopLogo() {
		return shopLogo;
	}

	public void setShopLogo(String shopLogo) {
		this.shopLogo = shopLogo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAboutUs() {
		return aboutUs;
	}

	public void setAboutUs(String aboutUs) {
		this.aboutUs = aboutUs;
	}

	private String shopLogo;//ͼƬ��ֻ��һ�ţ�û�оͷ���null
	private String phone;//��ҵֵ��绰
	private String address;//��ҵ��С����פ����ַ
	private String aboutUs;//��ҵ���

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Byte getIsActive() {
		return isActive;
	}

	public void setIsActive(Byte isActive) {
		this.isActive = isActive;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Integer likeCount) {
		this.likeCount = likeCount;
	}

	public Byte getOpened() {
		return opened;
	}

	public void setOpened(Byte opened) {
		this.opened = opened;
	}
}
