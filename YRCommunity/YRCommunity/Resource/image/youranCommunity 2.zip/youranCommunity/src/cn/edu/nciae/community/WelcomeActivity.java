package cn.edu.nciae.community;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.edu.nciae.community.domain.MyOperation;

import com.example.personal.R;

public class WelcomeActivity extends Activity implements OnPageChangeListener{

	String city, home;
	//��װ��������
	ViewPager viewpager;
	int ads[]={R.drawable.lead_01,R.drawable.lead_02,R.drawable.lead_03};
	List<View> items;
	ImageView image,dot,dots[];
	LinearLayout viewGroup;
	private int currentIndex = 0;
	Boolean f = true;
	ImageView firstLogin;
	//
	TextView tv_splash_version;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(isFirstLogin())
		{
			setContentView(R.layout.first_install);
			initViewPager();
			initDot();
		}
		else
		{
			setContentView(R.layout.welcome);
			into();
		}

	}

	

	private void into()
	{
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (!MyOperation
						.isExistCityAndCommunity(getApplicationContext())) {// ���ݱ��ش洢�ĳ�����Ϣ���ж��Ƿ�Ϊ��һ�ν��롣����Ϣ�����ڣ���ֱ��ѡ����к�С��
					Intent intent = new Intent(getApplicationContext(),
							AllOfCommunityListActivity.class);
					startActivity(intent);
					finish();
				} else {
					Intent intent = new Intent(getApplicationContext(),
							MainActivity.class);
					startActivity(intent);
					finish();// 2������������
				}
			}
		}, 2000);
	}


	private Boolean isFirstLogin()
	{
		SharedPreferences sharedPreferences = this.getSharedPreferences("share", MODE_PRIVATE); 
		boolean isFirstRun = sharedPreferences.getBoolean("isFirstRun", true); 
		Editor editor = sharedPreferences.edit(); 
		if (isFirstRun) 
		{ 
			Log.d("debug", "��һ������"); 
			editor.putBoolean("isFirstRun", false).commit();
			return true;
		} else 
		{ 
			Log.d("debug", "���ǵ�һ������"); 
			return false;
		} 
	}
	// @Override
	// protected void onRestart() {
	// // TODO Auto-generated method stub
	// Intent intent = new Intent(getApplicationContext(), MainActivity.class);
	// startActivity(intent);
	// finish();
	// super.onRestart();
	// }
	/**
	 *@TODO ��װ����Ĳ�������ʼ��dot��ͼ
	 *@project youranCommunity
	 *@Author �
	 *@DATA 2015-4-23 ����8:52:46
	 */
	private void initDot() {
		// TODO Auto-generated method stub
		viewGroup = (LinearLayout)findViewById(R.id.viewGroup);
		dots = new ImageView[items.size()];

		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(20,20);
		layoutParams.setMargins(50, 10, 50, 10);
		for(int i=0 ; i<items.size(); i++){
			dot = new ImageView(this);

			dot.setLayoutParams(layoutParams);  			
			dots[i] = dot;
			dots[i].setTag(i);
			dots[i].setOnClickListener(onClick);

			if (i == 0) {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotc);  
			} else {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotn);  
			}  

			viewGroup.addView(dots[i]);  
		}
	}

	//��ʼ��view��ͼ������viewpager��������	
	private void initViewPager() {
		// TODO Auto-generated method stub
		items = new ArrayList<View>();	
		//LinearLayout lin=(LinearLayout) findViewById(R.id.lin);
		for(int i=0; i<ads.length; i++){
			DisplayMetrics dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
		    int screenHeigh = dm.heightPixels;
			LinearLayout lin = new LinearLayout(this);
			lin.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
			lin.setOrientation(LinearLayout.VERTICAL);
			lin.setBackgroundResource(ads[i]);
			lin.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
			lin.setPadding(0, 0, 0, screenHeigh/25);
			if(i==ads.length-1)
			{
				firstLogin=new ImageButton(this);
				firstLogin.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				firstLogin.setBackgroundResource(R.drawable.lead_enter);
				firstLogin.setOnClickListener(new android.view.View.OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getApplicationContext(),
								AllOfCommunityListActivity.class);
						startActivity(intent);
						finish();
					}
				});
				lin.addView(firstLogin);

			}
			items.add(lin);
		}

		viewpager = (ViewPager)findViewById(R.id.viewpager);
		viewpager.setAdapter(adapter);
		viewpager.setOnPageChangeListener(this);
	}

	//ʵ��dot�����Ӧ����
	android.view.View.OnClickListener onClick = new View.OnClickListener(){

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int position = (Integer)v.getTag();  
			setCurView(position);  
			setCurDot(position);  
		}	

	};

	/** 
	 *���õ�ǰ������ҳ  
	 */  
	private void setCurView(int position)  
	{  
		if (position < 0 || position >= items.size()) {  
			return;  
		}  

		viewpager.setCurrentItem(position); 
		currentIndex = position;  
	}  

	/** 
	 *ѡ�е�ǰ����С��
	 */  
	private void setCurDot(int position)  
	{  
		if (position < 0 || position > items.size() - 1) {  
			return;  
		}  

		dots[position]  
				.setBackgroundResource(R.drawable.dotc);  

		currentIndex = position; 

	}  

	PagerAdapter adapter = new PagerAdapter(){

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return items.size();
		}

		@Override
		public void destroyItem(View container, int position, Object object) {
			// TODO Auto-generated method stub
			((ViewPager) container).removeView(items.get(position));
		}

		@Override
		public Object instantiateItem(View container, int position) {
			// TODO Auto-generated method stub
			((ViewPager) container).addView(items.get(position), 0);
			return items.get(position);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0 == arg1 ;
		}

	};

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageSelected(int arg0) {
		// TODO Auto-generated method stub
		if(arg0==dots.length-1)
		{
			viewGroup.setVisibility(4);
		}
		else
		{
			viewGroup.setVisibility(0);
		}
		for (int i = 0; i < dots.length; i++) {  
			dots[arg0]  
					.setBackgroundResource(R.drawable.dotc);  
			if (arg0 != i) {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotn);  
			}  
		}  
	}


}