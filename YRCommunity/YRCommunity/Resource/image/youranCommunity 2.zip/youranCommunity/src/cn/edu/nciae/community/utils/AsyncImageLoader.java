package cn.edu.nciae.community.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import cn.edu.nciae.community.app.CommunityApp;



public class AsyncImageLoader {
	private HashMap<String, SoftReference<Drawable>> imageCache;

public AsyncImageLoader() {
	imageCache = new HashMap<String, SoftReference<Drawable>>();
}

private static String getImageName(String url) {
	String imageName = url.substring(url.lastIndexOf("/") + 1) + ".jpg";
	return imageName;
}

public Drawable loadDrawable(final String imageUrl,
		final ImageCallback imageCallback) {

	if (imageCache.containsKey(imageUrl)) {
		SoftReference<Drawable> softReference = imageCache.get(imageUrl);
		Drawable drawable = softReference.get();
		if (drawable != null) {
			return drawable;
		}
	}

	final Handler handler = new Handler() {
		public void handleMessage(Message message) {
			imageCallback.imageLoaded((Drawable) message.obj, imageUrl);
		}
	}; 
	
	new Thread() {
		@Override
		public void run() {
			Drawable drawable = loadImageFromUrl(imageUrl);
			imageCache.put(imageUrl, new SoftReference<Drawable>(drawable));
			if (imageCallback != null) {
				Message message = handler.obtainMessage(0, drawable);
				handler.sendMessage(message);
			}
		}
	}.start();
	return null;
}

public static Drawable loadImageFromUrl(String url) {
	if (url.indexOf(CommunityApp.ASSETS_PATH_PREFIX) == 0) {
		try {
			return Drawable.createFromStream(
					CommunityApp.context.getAssets().open(
							url.substring(CommunityApp.ASSETS_PATH_PREFIX
									.length())), "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//�ӱ��ػ�ȡ  �� URL ��ַ
	if (url.indexOf("http://") != 0) {
		return Drawable.createFromPath(url);
	}

	String fileName = getImageName(url);

	File f = new File(CommunityApp.imgTmpDir, fileName);
	if (f.exists() == false) {

		// down load file as cache
		try {
			f.createNewFile();

			HttpClient client = new DefaultHttpClient();

			HttpGet get = new HttpGet(url);
			//int count=0;
		/*	while(Httphelper.getCookie()==null){
				count++;
				Thread.sleep(500);
				if(count==20){
					return null;
				}
			}
			if (Httphelper.getCookie() != null) {
				get.setHeader("Cookie", Httphelper.getCookie().getName()
						+ "=" + Httphelper.getCookie().getValue());
			}*/
			HttpResponse response = client.execute(get);
			if (response.getStatusLine().getStatusCode() == 200) {

				FileOutputStream fos = new FileOutputStream(
						CommunityApp.imgTmpDir + "/" + fileName);
				InputStream is = response.getEntity().getContent();
				byte[] bytes = new byte[1024 * 4];
				int len = 0;
				while ((len = is.read(bytes)) != -1) {
					fos.write(bytes, 0, len);
				}
				fos.flush();
				fos.close();
				is.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	return Drawable.createFromPath(f.getAbsolutePath());
}

public interface ImageCallback {
	public void imageLoaded(Drawable imageDrawable, String imageUrl);
}
}
