package cn.edu.nciae.community.domain;

public class Advertisement {

	private Integer id;
	private String adImagURL;//���ͼƬ����
	private String adTitle;//������
	private String adContent;//�������
	private Integer shopperId;//��������̼�id
	private String communityList;//�̼�Ҫ������С��id�б����մ���ȫ��С����
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAdImagURL() {
		return adImagURL;
	}
	public void setAdImagURL(String adImagURL) {
		this.adImagURL = adImagURL;
	}
	
	public String getAdTitle() {
		return adTitle;
	}
	public void setAdTitle(String adTitle) {
		this.adTitle = adTitle;
	}
	
	public String getAdContent() {
		return adContent;
	}
	public void setAdContent(String adContent) {
		this.adContent = adContent;
	}
	public Integer getShopperId() {
		return shopperId;
	}
	public void setShopperId(Integer shopperId) {
		this.shopperId = shopperId;
	}
	public String getCommunityList() {
		return communityList;
	}
	public void setCommunityList(String communityList) {
		this.communityList = communityList;
	}

}
