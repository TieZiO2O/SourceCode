package cn.edu.nciae.community.city;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.example.personal.R;

public class CityAdapter extends ContactListAdapter {

	public CityAdapter(Context _context, int _resource,
			List<ContactItemInterface> _items) {
		super(_context, _resource, _items);
	}

	public void populateDataForRow(View parentView, ContactItemInterface item,
			int position) {
		View infoView = parentView
				.findViewById(R.id.main_city_listitem_infoRowContainer);
		TextView nicknameView = (TextView) infoView
				.findViewById(R.id.main_city_listitem_tv2);

		nicknameView.setText(item.getDisplayInfo());
	}

}
