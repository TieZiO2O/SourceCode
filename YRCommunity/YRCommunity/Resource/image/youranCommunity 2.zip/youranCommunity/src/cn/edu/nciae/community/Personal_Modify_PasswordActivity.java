package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyToast;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.CipherUtil;

import com.example.personal.R;

public class Personal_Modify_PasswordActivity extends Activity {

	private EditText et_set_oldpassword;
	private EditText et_set_newpassword;
	private EditText et_set_confirmpassword;
	private Button tv_save_set_password;
	private final Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_modify_password);

		tv_save_set_password = (Button) findViewById(R.id.tv_save_set_password);
		tv_save_set_password.setOnClickListener(listener);

		et_set_oldpassword = (EditText) findViewById(R.id.et_set_oldpassword);
		et_set_oldpassword.setOnClickListener(listener);

		et_set_newpassword = (EditText) findViewById(R.id.et_set_newpassword);
		et_set_newpassword.setOnClickListener(listener);

		et_set_confirmpassword = (EditText) findViewById(R.id.et_set_confirmpassword);
		et_set_confirmpassword.setOnClickListener(listener);
		changeBack();
	}
	// �����¼�
	protected OnClickListener listener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.tv_save_set_password:
				if (et_set_oldpassword.getText().toString().trim().length() != 0) {
					if (et_set_newpassword.getText().toString().trim().length() != 0) {
						if (et_set_confirmpassword.getText().toString().trim().length() != 0) {
							if (et_set_confirmpassword
									.getText()
									.toString()
									.trim()
									.equals(et_set_newpassword.getText()
											.toString().trim())) {
								if (!MyOperation.judegPwd(et_set_newpassword.getText().toString().trim()).equals("")) {
									new MyToast(getApplicationContext(), "��ʾ",
											MyOperation.judegPwd(et_set_newpassword.getText().toString().trim()),Toast.LENGTH_SHORT);
									return;
								}
								final String Md5newpwd=CipherUtil.generatePassword(et_set_newpassword
										.getText()
										.toString());
								final String Md5oldped=CipherUtil.generatePassword(et_set_oldpassword
										.getText()
										.toString());
								
								new Thread() {
									@Override
									public void run() {
										try {
											HttpPost httpPost = new HttpPost(
													getResources().getString(
															R.string.base_url)
															+ "member/member_changepwd.do");

											ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
											NameValuePair nameValuePair = new BasicNameValuePair(
													"id",
													CommunityApp.getUserId());
											nvs.add(nameValuePair);
											nameValuePair = new BasicNameValuePair(
													"newPassword",
													Md5newpwd);
											nvs.add(nameValuePair);
											nameValuePair = new BasicNameValuePair(
													"oldPassword",
													Md5oldped);
											nvs.add(nameValuePair);

											httpPost.setEntity(new UrlEncodedFormEntity(
													nvs, "utf-8"));
											final String result = Httphelper
													.getValueFromNet(httpPost);
											System.out.println(result);
											if (result.indexOf("success") == 0) {
												SharedPreferences sp = getSharedPreferences(
														"user", MODE_PRIVATE);
												Editor editor = sp.edit();
												editor.putString("password",
														et_set_newpassword
														.getText()
														.toString());
												editor.commit();
												handler.post(new Runnable() {

													@Override
													public void run() {
														Toast.makeText(
																getBaseContext(),
																"�޸ĳɹ�", 0)
																.show();
														Personal_Modify_PasswordActivity.this
														.finish();
													}
												});
											} else if(result.indexOf("failed") == 0){
												handler.post(new Runnable() {

													@Override
													public void run() {
														Toast.makeText(
																getBaseContext(),
																"�޸�ʧ��",
																0).show();
													}
												});
											}

										} catch (Exception e) {
											e.printStackTrace();
											handler.post(new Runnable() {
												@Override
												public void run() {
													Toast.makeText(
															CommunityApp.context,
															"������ȥ���ǿ�����...", 0)
															.show();
												}
											});
										}
									}
								}.start();
							} else {
								Toast.makeText(getBaseContext(), "��������ȷ�����벻һ��",
										0).show();
							}
						} else {
							Toast.makeText(getBaseContext(), "���ٴ�����������", 0)
							.show();
						}
					} else {
						Toast.makeText(getBaseContext(), "������������", 0).show();
					}
				} else {
					Toast.makeText(getBaseContext(), "������ԭ����", 0).show();
				}
				break;

			}
		}
	};
	public void changeBack() {
		et_set_oldpassword
		.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					et_set_oldpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_selected);
				} else {
					et_set_oldpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
				}

			}
		});
		et_set_newpassword
		.setOnFocusChangeListener(new OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					et_set_newpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_selected);
				} else {
					et_set_newpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
				}
			}
		});
		et_set_confirmpassword
		.setOnFocusChangeListener(new OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					et_set_confirmpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_selected);
				} else {
					et_set_confirmpassword
					.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
				}
			}
		});
	}
	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}