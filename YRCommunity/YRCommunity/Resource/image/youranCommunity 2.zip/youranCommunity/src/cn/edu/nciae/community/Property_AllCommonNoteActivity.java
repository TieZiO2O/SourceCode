package cn.edu.nciae.community;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import cn.edu.nciae.community.domain.Bulletin;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.mycustom.RefreshableView;
import cn.edu.nciae.community.mycustom.RefreshableView.PullToRefreshListener;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.GsonUtils;

import com.example.personal.R;

public class Property_AllCommonNoteActivity extends Activity{
	ListView wuye_public_list_liebiao_list;
	RefreshableView refreshableView;

	Handler handler=new Handler();

	ArrayList<Map<String, Object>> listitem =new ArrayList<Map<String, Object>>();

	ArrayList<Bulletin>bulletins=new ArrayList<Bulletin>();//��Ŵӷ�������ȡ�Ĺ������

	public  Boolean isFistEnter=true;
	
	SimpleAdapter listItemAdapter;

	TextView wuye_public_list_title_text_rl_text;
	Runnable runnable;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.property_commonnote_list);
		
		refreshableView = (RefreshableView) findViewById(R.id.refreshable_view);
		//����ˢ���¼�
		refreshableView.setOnRefreshListener(new PullToRefreshListener() {

			@Override
			public void onRefresh() {
				// TODO Auto-generated method stub
				getBulletinMsgs();
			}
		}, 0);
		
		
		wuye_public_list_liebiao_list = (ListView) findViewById(R.id.wuye_public_list_liebiao_list);

		//����ʱ���������ȡ����
		getBulletinMsgs();//��ȡС��������Ϣ,�����bulletins


		// ���ü�����
		listItemAdapter = new SimpleAdapter(
				this, 
				getData(),
				R.layout.property_commonnote_listitem, 
				new String[] { "list_title","list_time" }, 
				new int[] {R.id.wuye_public_listitem_name_text,R.id.wuye_public_listitem_time_text });


		wuye_public_list_liebiao_list.setAdapter(listItemAdapter);

		// ListView�����¼�����
		wuye_public_list_liebiao_list
		.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getApplicationContext(),
						Property_CommonNoteActivity.class);
				Bundle bundle=new Bundle();
				bundle.putString("title", bulletins.get(position).getTitle());
				bundle.putString("time", bulletins.get(position).getCommitTime());
				bundle.putString("content", bulletins.get(position).getBulletinInfo());
				intent.putExtras(bundle);

				startActivity(intent);
			}
		});

	}

	//�������ȡ����
	private void getBulletinMsgs() {
		SharedPreferences sp=getSharedPreferences("myCityCommunity", MODE_PRIVATE);
		final String communityId=sp.getString("communityId", null);
		if (isFistEnter) {
			MyProgressDialog.startProgressDialog(Property_AllCommonNoteActivity.this, null);
			isFistEnter=false;
		}
		new Thread(){
			@Override
			public void run(){
				try {
					HttpPost httpPost = new HttpPost(getResources().getString(
							R.string.base_url)
							+ "member/mem_selectbulletin.do");
					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair(
							"communityid", communityId);
					nvs.add(nameValuePair);

					httpPost.setEntity(new UrlEncodedFormEntity(nvs));
					final String result = Httphelper.getValueFromNet(httpPost);


					Bulletin[] ms=GsonUtils.gsonToBulletin(result);//���ض���������

					int len=ms.length;
					
					if (len==0) {
						handler.post(new Runnable() {

							@Override
							public void run() {
									MyProgressDialog.stopProgressDialog();
								refreshableView.finishRefreshing();
								Toast.makeText(getApplicationContext(),
										"���޹���", 0).show();
							}
						});
						return;
					}

					bulletins=new ArrayList<Bulletin>();
					for(int i=0;i<len;i++){
						bulletins.add(ms[i]);
					}
					getData();
					handler.post(new Runnable()
					{

						@Override
						public void run()
						{
								MyProgressDialog.stopProgressDialog();
							refreshableView.finishRefreshing();
							listItemAdapter.notifyDataSetChanged();
						}
					});
				} catch ( Exception e) {
					handler.post(new Runnable() {
						
						@Override
						public void run() {
							MyProgressDialog.stopProgressDialog();
							refreshableView.finishRefreshing();
							if (!MyOperation.IsNetConnection(Property_AllCommonNoteActivity.this)) {

								Toast.makeText(getApplicationContext(),
										"���������ӣ����������", 0).show();
								return;
							}
							Toast.makeText(getApplicationContext(),
									"���ӷ�����ʧ�ܣ����Ժ�����", 0).show();
						}
					});
				}
			}
		}.start();

	}

	/**
	 *@TODO �����ݵ�listitem
	 *@project youranCommunity
	 *@return
	 *@Author Mr Rui
	 *@DATA 2015-4-24 ����3:43:28
	 */
	private List<Map<String, Object>> getData() {

		//				listitem= new ArrayList<Map<String, Object>>();
		listitem.clear();
		if (bulletins!=null) {
			for (int i = 0; i < bulletins.size(); i++) {
				Map<String, Object> map = new HashMap<String, Object>();

				map.put("list_title", bulletins.get(i).getTitle());
				map.put("list_time", bulletins.get(i).getCommitTime());
				listitem.add(map);
			}
		}
		return listitem;
	}
	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
