package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.net.Httphelper;

import com.example.personal.R;

public class Property_MySuggestionActivity extends Activity {
	private final Handler handler = new Handler();
	EditText et_property_my_suggestion;
	ProgressBar pb;
	SharedPreferences spCommunity;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.property_mysuggestion);
		et_property_my_suggestion = (EditText) findViewById(R.id.wuye_suggestion_et);
		pb=(ProgressBar)findViewById(R.id.pb_property_mysuggestion);
		spCommunity = getSharedPreferences("myCityCommunity",
				MODE_PRIVATE);
	}

	public void submitwuye(View view) {
		if (et_property_my_suggestion.getText().length()!=0) {
			if (!MyOperation.IsNetConnection(Property_MySuggestionActivity.this)) {
				Toast.makeText(getApplicationContext(), "���ӷ�����ʧ�ܣ����������", 0).show();
				return;
			}
			String mysuggestion = et_property_my_suggestion.getText()
					.toString().trim();
			submmitMySuggestion(mysuggestion);
			
		}
		else {
			Toast.makeText(getApplicationContext(), "���ݲ���Ϊ�գ�", 0).show();
		}
	}
	
	//�����ҵ��������ҵ
	public void submmitMySuggestion(String Suggestion) {

		final String suggestion = Suggestion;
		pb.setVisibility(View.VISIBLE);
		new Thread() {
			@Override
			public void run() {
				try {
					HttpPost httpPost = new HttpPost(getResources().getString(
							R.string.base_url)
							+ "member/insertreply.do");
					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair("memid",
							CommunityApp.getUserId());
					nvs.add(nameValuePair);
					
					nameValuePair = new BasicNameValuePair("communityid",
							spCommunity.getString("communityId",null));
					nvs.add(nameValuePair);
					nameValuePair = new BasicNameValuePair("msg",
							suggestion);
					nvs.add(nameValuePair);
					httpPost.setEntity(new UrlEncodedFormEntity(nvs, "utf-8"));
					final String result = Httphelper.getValueFromNet(httpPost);
					if (result.indexOf("success") == 0) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								pb.setVisibility(View.INVISIBLE);
								Toast.makeText(getBaseContext(), "��л���ķ���", 0)
										.show();
								Property_MySuggestionActivity.this.finish();
							}
						});
					} else if (result.indexOf("failed") == 0) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								pb.setVisibility(View.INVISIBLE);
								Toast.makeText(getBaseContext(), "�Բ��𣬷������°�����",
										0).show();
							}
						});
					}

				} catch (Exception e) {
					e.printStackTrace();
					handler.post(new Runnable() {
						@Override
						public void run() {
							pb.setVisibility(View.INVISIBLE);
							Toast.makeText(CommunityApp.context,
									"������ȥ���ǿ�����...", 0).show();
						}
					});
				}
			}

		}.start();

	}
	
	
	
	//����ͼƬ��ť�����
    public void onBackImageClick(View view)
    {
    	getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    	finish();
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			getWindow().setSoftInputMode(
					WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}