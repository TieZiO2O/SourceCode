package cn.edu.nciae.community.fragments;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import cn.edu.nciae.community.app.CommunityApp;

import com.example.personal.R;

public class Fragment2 extends Fragment {

	private View view, viewAlreadyLogin, viewNotLogin;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.main_personal, container, false);
		viewAlreadyLogin = view.findViewById(R.id.main_personal_already_login);
		viewNotLogin = view.findViewById(R.id.main_personal_not_login);
		return view;
	}

	// ����û���¼״̬
	
	@SuppressWarnings("static-access")
	public void checkUser() {
		if (view == null) {
			return;
		}
		if (CommunityApp.getUser() == null) {// δ��¼�ɹ�
			viewNotLogin.setVisibility(view.VISIBLE);//��ʾδ��¼����
			viewAlreadyLogin.setVisibility(view.INVISIBLE);//�ѵ�¼���治�ɼ�
		} else {// ��¼�ɹ�
			viewNotLogin.setVisibility(view.INVISIBLE);//δ��¼���治�ɼ�
			viewAlreadyLogin.setVisibility(view.VISIBLE);//��ʾ��½�����
			TextView tv = (TextView) viewAlreadyLogin
					.findViewById(R.id.personal_login_name_textview); 
			tv.setText(CommunityApp.getUser().getName());
		}
	}
	
	
	
}
