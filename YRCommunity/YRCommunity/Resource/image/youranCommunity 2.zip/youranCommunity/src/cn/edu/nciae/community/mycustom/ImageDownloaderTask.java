package cn.edu.nciae.community.mycustom;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Comparator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import cn.edu.nciae.community.Business_AllUserActivity;
import cn.edu.nciae.community.Business_ImagesWitcherActivity;
import cn.edu.nciae.community.Business_InfoActivity;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.fragments.Fragment1;

public class ImageDownloaderTask<object> extends
		AsyncTask<String, Void, Bitmap> {

	Object object = CommunityApp.object;// ��ȡ������ת��Activity

	private static String TAG = ImageDownloaderTask.class.getSimpleName();
	private static final int IO_BUFFER_SIZE = 4 * 1024;// ����ռ�
	private static final int MB = 1024 * 1024;

	// �����ܴ�С���� 1024 * 1024
	private static final int CACHE_SIZE = 1024 * 1024;
	private static final int mTimeDiff = 5 * 24 * 60 * 60 * 1000;

	// SDCardʣ��ռ����� 30
	private static final int FREE_SD_SPACE_NEEDED_TO_CACHE = 30;
	String WHOLESALE_CONV = Environment.getExternalStorageDirectory()
			+ "/community/tmp/img";
	private String url;
	private final WeakReference<object> activityReference;

	public ImageDownloaderTask(object activity) {
		activityReference = new WeakReference<object>(activity);
	}

	@Override
	protected Bitmap doInBackground(String... params) {
		url = params[0].trim();
		String filename = convertUrlToFileName(url);
		String dir = getDirectory();

		File file = new File(dir + "/" + filename);

		if (file.exists()) {

			removeExpiredCache(dir, filename);
			updateFileTime(dir, filename);
			Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
			if (bitmap != null) {
				return bitmap;
			}
		}

		final DefaultHttpClient client = new DefaultHttpClient();
		final HttpGet getRequest = new HttpGet(url);
		try {

			HttpResponse response = client.execute(getRequest);
			final int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != HttpStatus.SC_OK) {
				return null;
			}
			final HttpEntity entity = response.getEntity();
			if (entity != null) {
				InputStream inputStream = null;
				OutputStream outputStream = null;
				try {
					inputStream = entity.getContent();
					final ByteArrayOutputStream dataStream = new ByteArrayOutputStream();
					outputStream = new BufferedOutputStream(dataStream,
							IO_BUFFER_SIZE);
					copy(inputStream, outputStream);
					outputStream.flush();
					final byte[] data = dataStream.toByteArray();
					final Bitmap bitmap = BitmapFactory.decodeByteArray(data,
							0, data.length);
					saveBmpToSd(bitmap, url);// ���浽SDCard
					return bitmap;
				} finally {
					closeStream(inputStream);
					closeStream(outputStream);
					entity.consumeContent();
				}
			}
		} catch (IOException e) {
			getRequest.abort();
		}
		return null;
	}

	@Override
	protected void onPostExecute(Bitmap result) {// onPostExecute����������ִ�����̨��������UI,��ʾ���
		super.onPostExecute(result);
		object act = activityReference.get();
		if (act != null && result != null) {
			if (object == Business_AllUserActivity.class) {
				((Business_AllUserActivity) act).onComplete(url.trim(), result);
			} else if (object == Business_InfoActivity.class) {
				((Business_InfoActivity) act).onComplete(url.trim(), result);
			} else if (object == Fragment1.class) {
				((Fragment1) act).onComplete(url.trim(), result);
			}else if (object == Business_ImagesWitcherActivity.class) {
				((Business_ImagesWitcherActivity) act).onComplete(url.trim(), result);
			}
		}
	}

	// ʹ�����ֽ�����������{@value #IO_BUFFER_SIZE},���������п������ݵ������

	public static void copy(InputStream in, OutputStream out)
			throws IOException {
		byte[] b = new byte[IO_BUFFER_SIZE];
		int read;
		while ((read = in.read(b)) != -1) {
			out.write(b, 0, read);
		}
	}

	// �ر���
	public static void closeStream(Closeable stream) {
		if (stream != null) {
			try {
				stream.close();
			} catch (IOException e) {
				android.util.Log.e(TAG, "Could not close stream", e);
			}
		}
	}

	// ���������ȡ��ͼƬ���浽SDCard

	private void saveBmpToSd(Bitmap bm, String url) {
		if (bm == null) {
			Log.w(TAG, " trying to savenull bitmap");
			return;
		}
		// �ж�sdcard�ϵĿռ�
		if (FREE_SD_SPACE_NEEDED_TO_CACHE > freeSpaceOnSd()) {
			Log.w(TAG, "Low free space onsd, do not cache");
			removeCache(WHOLESALE_CONV);
			return;
		}
		String filename = convertUrlToFileName(url);
		String dir = getDirectory();
		File file = new File(dir + "/" + filename);
		try {
			file.createNewFile();
			OutputStream outStream = new FileOutputStream(file);
			bm.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
			outStream.flush();
			outStream.close();
		} catch (FileNotFoundException e) {
			Log.w("tosd", e.getMessage());
		} catch (IOException e) {
			Log.w("tosd", e.getMessage());
		}
	}

	// ��url�����һ��"/"�����ȡ������Ϊ�ļ���

	private String convertUrlToFileName(String url) {
		int lastIndex = url.lastIndexOf('/');
		return url.substring(lastIndex + 1);
	}

	// ��ȡ����ĸ�Ŀ¼��ַ
	private String getDirectory() {
		return WHOLESALE_CONV;
	}

	// ����sdcard�ϵ�ʣ��ռ�
	private int freeSpaceOnSd() {
		StatFs stat = new StatFs(Environment.getExternalStorageDirectory()
				.getPath());
		double sdFreeMB = ((double) stat.getAvailableBlocks() * (double) stat
				.getBlockSize()) / MB;
		return (int) sdFreeMB;
	}

	// �޸��ļ�������޸�ʱ��
	private void updateFileTime(String dir, String fileName) {
		File file = new File(dir, fileName);
		long newModifiedTime = System.currentTimeMillis();
		file.setLastModified(newModifiedTime);
	}

	// ����洢Ŀ¼�µ��ļ���С��
	// ���ļ��ܴ�С���ڹ涨��CACHE_SIZE����sdcardʣ��ռ�С��FREE_SD_SPACE_NEEDED_TO_CACHE�Ĺ涨
	// ��ôɾ��40%���û�б�ʹ�õ��ļ�

	private void removeCache(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null) {
			return;
		}
		int dirSize = 0;
		for (int i = 0; i < files.length; i++) {
			if (files[i].getName().contains(WHOLESALE_CONV)) {
				dirSize += files[i].length();
			}
		}
		if (dirSize > CACHE_SIZE * MB
				|| FREE_SD_SPACE_NEEDED_TO_CACHE > freeSpaceOnSd()) {
			int removeFactor = (int) ((0.4 * files.length) + 1);

			Arrays.sort(files, new FileLastModifSort());

			Log.i(TAG, "Clear some expiredcache files ");

			for (int i = 0; i < removeFactor; i++) {

				if (files[i].getName().contains(WHOLESALE_CONV)) {

					files[i].delete();

				}

			}

		}

	}

	// �����ļ�������޸�ʱ��������� *
	class FileLastModifSort implements Comparator<File> {
		@Override
		public int compare(File arg0, File arg1) {
			if (arg0.lastModified() > arg1.lastModified()) {
				return 1;
			} else if (arg0.lastModified() == arg1.lastModified()) {
				return 0;
			} else {
				return -1;
			}
		}
	}

	// ɾ�������ļ�
	private void removeExpiredCache(String dirPath, String filename) {
		File file = new File(dirPath, filename);
		if (System.currentTimeMillis() - file.lastModified() > mTimeDiff) {
			file.delete();
		}

	}
}