package cn.edu.nciae.community.city;

import java.util.ArrayList;

import cn.edu.nciae.community.city.HanziToPinyin3.Token;

public class PinYin {
	// 汉字返回拼音，字母原样返回，都转换为小写
	public static String getPinYin(String input) {

		ArrayList<Token> tokens = HanziToPinyin3.getInstance().get(input);
		StringBuilder sb = new StringBuilder();
		if (tokens != null && tokens.size() > 0) {
			for (Token token : tokens) {
				if (Token.PINYIN == token.type) {
					sb.append(token.target);
				} else {
					sb.append(token.source);
				}
			}
		}
		// 处理不能识别的多音字
		if (input.equals("乐清")) {
			return "yueqing";
		}
		if (input.equals("重庆")) {
			return "chongqing";
		}
		// 判断热门城市
		if (!input.equals(input.trim())) {// 因为热门城市后面加了空格，去空格前后不同
			return "#";
		}
		return sb.toString().toLowerCase();
	}
}
