package cn.edu.nciae.community.fragments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import cn.edu.nciae.community.Business_AllUserActivity;
import cn.edu.nciae.community.Business_InfoActivity;
import cn.edu.nciae.community.MainActivity;
import cn.edu.nciae.community.adapter.AdvertisementAdapter;
import cn.edu.nciae.community.domain.Advertisement;
import cn.edu.nciae.community.mycustom.ListViewForScrollView;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.JsonUtil;

import com.example.personal.R;

public class Fragment1 extends Fragment {

	// �ܱ߷����0��ȫ�Ƿ����1
	private String serverRange;
	// ��ŷ������
	private String serverType;

	private View view;
	int i;
	// ��¼�ܱ߷����ȫ�Ƿ���ÿһҳ�ָ���
	private final int first_scrollview_count = 6;
	private final int second_scrollview_count = 3;
	// �ܱ߷����ȫ�Ƿ��������Դ
	int[] imageResId = { R.drawable.mygouwu, R.drawable.myshop,
			R.drawable.myjinrong, R.drawable.mybaojie, R.drawable.mykaisuo,
			R.drawable.myweixiu, R.drawable.mylifa };
	int[] imageResId2 = { R.drawable.mybanjia, R.drawable.mycheliang,
			R.drawable.mylvyou };
	String[] stringId = { "��ʳ����", "�̳�����", "��������", "��������", "��ͨ����", "�ҵ�ά��",
			"��������" };
	String[] stringId2 = { "���װ��", "��������", "��������" };
	// ���һ���
	ViewPager viewpager, viewpagertwo;
	List<View> items, itemstwo;
	ImageView image, imagetwo, dot, dottwo, dots[], dotstwo[];
	LinearLayout viewGroup, viewGrouptwo;
	// ��ΪOnItemClick�ĵ��ڲ���ļ���
	int currentIndex = 0, currentIndextwo = 0;
	Boolean f = true;
	LinearLayout shangjia_jiugongge_frag0[], shangjia_jiugongge_frag1[];
	public GridView main_shangjia_grid[], main_shangjia_gridtwo[];

	// �̼ҹ��ListView 
	ListViewForScrollView ll_fragment1_advertisement;
	private ArrayList<Advertisement> ads = null;
	private volatile boolean isLoadedOk = false;
	private AdvertisementAdapter adapter;
    private String communityId;
    SharedPreferences sp;
    String FLAG = "from_fragment1_advertisement";
	// MyListAdapter listItemAdapter;

	Handler handler = new Handler();

	ArrayList<Map<String, Object>> listitem = new ArrayList<Map<String, Object>>();
	ArrayList<Advertisement> adData = new ArrayList<Advertisement>();// ��Ź������

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.main_business, container, false);
		ll_fragment1_advertisement = (ListViewForScrollView) view
				.findViewById(R.id.ll_fragment1_advertisement);
		
		ll_fragment1_advertisement.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Advertisement advertisement=ads.get(position);
				final String shopperId=advertisement.getShopperId().toString();
				Intent intent = new Intent(
						MainActivity.instance,
						Business_InfoActivity.class);

				Bundle bundle = new Bundle();
				bundle.putString("shopperid", shopperId);// ���̼�id
				bundle.putString("flag", FLAG);
				intent.putExtras(bundle);
				startActivity(intent);
				
			}
		});
		ScrollView sv = (ScrollView) view
				.findViewById(R.id.main_shangjia_scrollview);
		sv.setVerticalScrollBarEnabled(false);// ��ֱ���������ɼ�
		sv.smoothScrollTo(0, 0);

		GridViewinit();
		initViewPager();
		initDot();
		operateForMerchant();
		operateForMerchanttwo();
		
		
		sp=getActivity().getSharedPreferences("myCityCommunity", 0); 
		communityId=sp.getString("communityId", null); 
		// ���
		getAdsvertisementInfo();
		return view;
	}

	// ��GriidView����ռ�
	private void GridViewinit() {
		shangjia_jiugongge_frag0 = new LinearLayout[imageResId.length
				/ first_scrollview_count + 1];
		shangjia_jiugongge_frag1 = new LinearLayout[imageResId2.length
				/ second_scrollview_count + 1];
		main_shangjia_grid = new GridView[imageResId.length
				/ first_scrollview_count + 1];
		main_shangjia_gridtwo = new GridView[imageResId2.length
				/ second_scrollview_count + 1];
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub

		super.onActivityResult(requestCode, resultCode, data);
	}

	// ���ܱ߷���ľŹ���Ĳ���
	private void operateForMerchant() {

		for (i = 0; i < main_shangjia_grid.length; i++) {
			ArrayList<HashMap<String, Object>> mArrayList = new ArrayList<HashMap<String, Object>>();
			if (i < main_shangjia_grid.length - 1) {
				for (int j = i * first_scrollview_count; j < (i + 1)
						* first_scrollview_count; j++) {
					HashMap<String, Object> mHashMap = new HashMap<String, Object>();
					mHashMap.put("ItemImage", imageResId[j]);
					mHashMap.put("ItemText", stringId[j]);
					mArrayList.add(mHashMap);
				}
			} else {
				for (int j = i * first_scrollview_count; j < imageResId.length; j++) {
					HashMap<String, Object> mHashMap = new HashMap<String, Object>();
					mHashMap.put("ItemImage", imageResId[j]);
					mHashMap.put("ItemText", stringId[j]);
					mArrayList.add(mHashMap);
				}
			}
			SimpleAdapter mSimpleAdapter = new SimpleAdapter(getActivity(),
					mArrayList, R.layout.business_item, new String[] {
							"ItemImage", "ItemText" },
					new int[] { R.id.item_jiugongge_image,
							R.id.item_jiugongge_text });

			main_shangjia_grid[i].setAdapter(mSimpleAdapter);

			main_shangjia_grid[i]
					.setOnItemClickListener(new OnItemClickListener() {
						@SuppressWarnings("unchecked")
						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							if (arg0 != null) {
								HashMap<String, Object> item = (HashMap<String, Object>) arg0
										.getItemAtPosition(arg2);

								serverRange = "0";// �����ܱ߷���
								serverType = ((String) item.get("ItemText"))
										.trim();// ��ŷ�������

								Intent intent = new Intent();
								intent.putExtra("serverRange", serverRange);
								intent.putExtra("serverType", serverType);
								intent.setClass(getActivity(),
										Business_AllUserActivity.class);
								startActivity(intent);
							}
						}
					});
		}
	}

	// ��ȫ�Ƿ���Ź���Ĳ���
	private void operateForMerchanttwo() {
		for (int i = 0; i < main_shangjia_gridtwo.length; i++) {
			ArrayList<HashMap<String, Object>> mArrayList = new ArrayList<HashMap<String, Object>>();
			if (i < main_shangjia_gridtwo.length - 1) {
				for (int j = i * second_scrollview_count; j < (i + 1)
						* second_scrollview_count; j++) {
					HashMap<String, Object> mHashMap = new HashMap<String, Object>();
					mHashMap.put("ItemImage", imageResId2[j]);
					mHashMap.put("ItemText", stringId2[j]);
					mArrayList.add(mHashMap);
				}
			} else {
				for (int j = i * second_scrollview_count; j < imageResId2.length; j++) {
					HashMap<String, Object> mHashMap = new HashMap<String, Object>();
					mHashMap.put("ItemImage", imageResId2[j]);
					mHashMap.put("ItemText", stringId2[j]);
					mArrayList.add(mHashMap);
				}
			}
			// final int count=i;
			SimpleAdapter mSimpleAdapter = new SimpleAdapter(getActivity(),
					mArrayList, R.layout.business_item, new String[] {
							"ItemImage", "ItemText" },
					new int[] { R.id.item_jiugongge_image,
							R.id.item_jiugongge_text });
			main_shangjia_gridtwo[i].setAdapter(mSimpleAdapter);
			main_shangjia_gridtwo[i]
					.setOnItemClickListener(new OnItemClickListener() {
						@SuppressWarnings("unchecked")
						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							if (arg0 != null) {
								HashMap<String, Object> item = (HashMap<String, Object>) arg0
										.getItemAtPosition(arg2);

								// String class_name = (String)
								// item.get("ItemText");
								// System.out.println("λ��Ϊ��" + arg2);
								// String class_position =
								// Integer.toString(arg2+imageResId.length+count*second_scrollview_count);

								serverRange = "1";// ����ȫ�Ƿ���
								serverType = ((String) item.get("ItemText"))
										.trim();// ��ŷ�������

								Intent intent = new Intent();
								intent.putExtra("serverRange", serverRange);
								intent.putExtra("serverType", serverType);

								intent.setClass(getActivity(),
										Business_AllUserActivity.class);
								startActivity(intent);
							}
						}

					});
		}
	}
	
	//��ȡ�����Ϣ
	// ��ȡ�����ղ�
		public void getAdsvertisementInfo() {
			if (isLoadedOk) {
				return;
			}
			
			new Thread() {
				@Override
				public void run() {
					// while (CommunityApp.getUserId() == null);
					try {
						HttpPost httpPost = new HttpPost(getResources().getString(
								R.string.base_url)
								+ "member/mem_selectads.do");

						ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
						NameValuePair nameValuePair = new BasicNameValuePair(
								"communityid", communityId);
						nvs.add(nameValuePair);

						httpPost.setEntity(new UrlEncodedFormEntity(nvs, "UTF-8"));
						String resultString = Httphelper.getValueFromNet(httpPost);
						
//						System.out.println("��������Ϣ---" +resultString);
						Advertisement[] adsvertisement = JsonUtil
								.gsonToadAdvertisements(resultString);
						ads = null;
						ads = new ArrayList<Advertisement>();
						int len = adsvertisement.length;
						for (int i = 0; i < len; i++) {
							ads.add(adsvertisement[i]);
						}
						handler.post(new Runnable() {

							@Override
							public void run() {
								adapter = new AdvertisementAdapter(MainActivity.instance,
										ads, ll_fragment1_advertisement);
								adapter.setShops(ads);
								adapter.notifyDataSetChanged();
								ll_fragment1_advertisement.setAdapter(adapter);
							}
						});
						// isLoadedOk = true;
					} catch (Exception e) {
						// isLoadedOk = false;
						e.printStackTrace();
					}
				}
			}.start();
		}

	

	// ��SDCard�������ȡͼƬ��Ļص�������֪ͨlistview����
	public void onComplete(String url, Bitmap result) {
		// TODO Auto-generated method stub
		ImageView iv = (ImageView) ll_fragment1_advertisement
				.findViewWithTag(url);// ����Tag��ǩ�ҵ���Ӧ��imageview������
		if (iv != null) {
			iv.setImageBitmap(result);
		}
	}

	// ��ʼ��dot��ͼ
	private void initDot() {
		viewGroup = (LinearLayout) view
				.findViewById(R.id.main_shangjia_viewGroup);
		viewGrouptwo = (LinearLayout) view
				.findViewById(R.id.main_shangjia_viewGrouptwo);
		dots = new ImageView[items.size()];
		dotstwo = new ImageView[itemstwo.size()];
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
				20, 20);
		layoutParams.setMargins(4, 3, 4, 3);

		for (int i = 0; i < items.size(); i++) {
			dot = new ImageView(getActivity());
			dot.setLayoutParams(layoutParams);
			dots[i] = dot;
			dots[i].setTag(i);
			dots[i].setOnClickListener(onClick);

			if (i == 0) {
				dots[i].setBackgroundResource(R.drawable.dotc);

			} else {
				dots[i].setBackgroundResource(R.drawable.dotn);

			}

			viewGroup.addView(dots[i]);
		}
		for (int i = 0; i < itemstwo.size(); i++) {
			dottwo = new ImageView(getActivity());
			dottwo.setLayoutParams(layoutParams);
			dotstwo[i] = dottwo;
			dotstwo[i].setTag(i);
			dotstwo[i].setOnClickListener(onClicktwo);

			if (i == 0) {
				dotstwo[i].setBackgroundResource(R.drawable.dotc);

			} else {
				dotstwo[i].setBackgroundResource(R.drawable.dotn);

			}

			viewGrouptwo.addView(dotstwo[i]);
		}
		if (imageResId2.length <= second_scrollview_count) {
			viewGrouptwo.setVisibility(4);
		}
	}

	private void initUI() {
		for (int i = 0; i < shangjia_jiugongge_frag0.length; i++) {
			shangjia_jiugongge_frag0[i] = new LinearLayout(getActivity());
			shangjia_jiugongge_frag0[i].setLayoutParams(new LayoutParams(
					LinearLayout.LayoutParams.MATCH_PARENT,
					LinearLayout.LayoutParams.WRAP_CONTENT));
			shangjia_jiugongge_frag0[i].setOrientation(LinearLayout.VERTICAL);
			shangjia_jiugongge_frag0[i].setBackgroundColor(Color.WHITE);
			main_shangjia_grid[i] = new GridView(getActivity());
			main_shangjia_grid[i].setLayoutParams(new LayoutParams(
					LinearLayout.LayoutParams.WRAP_CONTENT,
					LinearLayout.LayoutParams.WRAP_CONTENT));
			main_shangjia_grid[i].setColumnWidth(5);
			main_shangjia_grid[i].setGravity(Gravity.CENTER);
			main_shangjia_grid[i].setHorizontalSpacing(3);
			main_shangjia_grid[i].setNumColumns(3);
			main_shangjia_grid[i].setSelector(R.drawable.grally_selector);
			main_shangjia_grid[i].setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			main_shangjia_grid[i].setVerticalSpacing(50);
			main_shangjia_grid[i].setPadding(0, 12, 0, 12);
			shangjia_jiugongge_frag0[i].addView(main_shangjia_grid[i]);
		}
		for (int i = 0; i < shangjia_jiugongge_frag1.length; i++) {
			shangjia_jiugongge_frag1[i] = new LinearLayout(getActivity());
			shangjia_jiugongge_frag1[i].setLayoutParams(new LayoutParams(
					LinearLayout.LayoutParams.MATCH_PARENT,
					LinearLayout.LayoutParams.WRAP_CONTENT));
			shangjia_jiugongge_frag1[i].setOrientation(LinearLayout.VERTICAL);
			shangjia_jiugongge_frag1[i].setBackgroundColor(Color.WHITE);
			main_shangjia_gridtwo[i] = new GridView(getActivity());
			main_shangjia_gridtwo[i].setLayoutParams(new LayoutParams(
					LinearLayout.LayoutParams.WRAP_CONTENT,
					LinearLayout.LayoutParams.WRAP_CONTENT));
			main_shangjia_gridtwo[i].setColumnWidth(5);
			main_shangjia_gridtwo[i].setGravity(Gravity.CENTER);
			main_shangjia_gridtwo[i].setHorizontalSpacing(3);
			main_shangjia_gridtwo[i].setNumColumns(3);
			main_shangjia_gridtwo[i].setSelector(R.drawable.grally_selector);
			main_shangjia_gridtwo[i]
					.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			main_shangjia_gridtwo[i].setVerticalSpacing(50);
			main_shangjia_gridtwo[i].setPadding(0, 12, 0, 12);
			shangjia_jiugongge_frag1[i].addView(main_shangjia_gridtwo[i]);
		}
	}

	// ��ʼ��view��ͼ������viewpager��������
	private void initViewPager() {
		// TODO Auto-generated method stub
		items = new ArrayList<View>();
		itemstwo = new ArrayList<View>();
		initUI();
		if (imageResId.length % first_scrollview_count == 0) {
			for (int i = 0; i < shangjia_jiugongge_frag0.length - 1; i++) {
				items.add(shangjia_jiugongge_frag0[i]);
			}
		} else {
			for (int i = 0; i < shangjia_jiugongge_frag0.length; i++) {
				items.add(shangjia_jiugongge_frag0[i]);
			}
		}
		if (imageResId2.length % second_scrollview_count == 0) {
			for (int i = 0; i < shangjia_jiugongge_frag1.length - 1; i++) {
				itemstwo.add(shangjia_jiugongge_frag1[i]);
			}
		} else {
			for (int i = 0; i < shangjia_jiugongge_frag1.length; i++) {
				itemstwo.add(shangjia_jiugongge_frag1[i]);
			}
		}
		viewpager = (ViewPager) view.findViewById(R.id.main_shangjia_viewpager);
		viewpagertwo = (ViewPager) view
				.findViewById(R.id.main_shangjia_viewpagertwo);
		viewpager.setAdapter(new PagerAdapter() {

			@Override
			public int getCount() {
				// TODO Auto-generated method stub
				return items.size();
			}

			@Override
			public void destroyItem(View container, int position, Object object) {
				// TODO Auto-generated method stub
				((ViewPager) container).removeView(items.get(position));
			}

			@Override
			public Object instantiateItem(View container, int position) {
				// TODO Auto-generated method stub
				((ViewPager) container).addView(items.get(position), 0);
				return items.get(position);
			}

			@Override
			public boolean isViewFromObject(View arg0, Object arg1) {
				// TODO Auto-generated method stub
				return arg0 == arg1;
			}

		});
		viewpagertwo.setAdapter(new PagerAdapter() {

			@Override
			public int getCount() {
				// TODO Auto-generated method stub
				return itemstwo.size();
			}

			@Override
			public void destroyItem(View container, int position, Object object) {
				// TODO Auto-generated method stub
				((ViewPager) container).removeView(itemstwo.get(position));
			}

			@Override
			public Object instantiateItem(View container, int position) {
				// TODO Auto-generated method stub
				((ViewPager) container).addView(itemstwo.get(position), 0);
				return itemstwo.get(position);
			}

			@Override
			public boolean isViewFromObject(View arg0, Object arg1) {
				// TODO Auto-generated method stub
				return arg0 == arg1;
			}

		});
		viewpager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				for (int i = 0; i < dots.length; i++) {
					dots[arg0].setBackgroundResource(R.drawable.dotc);
					if (arg0 != i) {
						dots[i].setBackgroundResource(R.drawable.dotn);
					}
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});
		viewpagertwo.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				for (int i = 0; i < dotstwo.length; i++) {
					dotstwo[arg0].setBackgroundResource(R.drawable.dotc);
					if (arg0 != i) {
						dotstwo[i].setBackgroundResource(R.drawable.dotn);
					}
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});
	}

	// ʵ��dot�����Ӧ����
	OnClickListener onClick = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int position = (Integer) v.getTag();
			setCurView(position);
			setCurDot(position);
		}

	};
	OnClickListener onClicktwo = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int position = (Integer) v.getTag();
			setCurViewtwo(position);
			setCurDottwo(position);
		}

	};

	// ���õ�ǰ������ҳ

	private void setCurView(int position) {
		if (position < 0 || position >= items.size()) {
			return;
		}

		viewpager.setCurrentItem(position);
		currentIndex = position;
	}

	private void setCurViewtwo(int position) {
		if (position < 0 || position >= itemstwo.size()) {
			return;
		}

		viewpagertwo.setCurrentItem(position);
		currentIndextwo = position;
	}

	// ѡ�е�ǰ����С��

	private void setCurDot(int position) {
		if (position < 0 || position > items.size() - 1) {
			return;
		}

		dots[position].setBackgroundResource(R.drawable.dotc);

		currentIndex = position;

	}

	private void setCurDottwo(int position) {
		if (position < 0 || position > itemstwo.size() - 1) {
			return;
		}

		dotstwo[position].setBackgroundResource(R.drawable.dotc);

		currentIndextwo = position;

	}
}