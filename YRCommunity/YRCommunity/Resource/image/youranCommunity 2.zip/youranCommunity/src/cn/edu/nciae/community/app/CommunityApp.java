package cn.edu.nciae.community.app;

import java.io.File;

import com.example.personal.R;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import cn.edu.nciae.community.domain.Users;
import cn.edu.nciae.community.utils.UploadUtil;
import cn.edu.nciae.community.utils.error.MyExceptionHandler;

public class CommunityApp extends Application {

	public static Context context;
	public static final String ASSETS_PATH_PREFIX = "file:///android_asset/";
	public static File imgTmpDir;
	public static File tmpDir;
	public static File logDir;
	public static File baseDir;
	public static Object object;
	private static SharedPreferences sp = null;
	private static Users user = null;
	public static boolean isLoadNew=false;
	private static boolean AdFlag;//�Ƿ���ع���棬true��ʾ���ع��ˣ�������δ����

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();

		// ��ʼ���ļ�·��
		baseDir = new File(Environment.getExternalStorageDirectory()
				+ "/community");
		if (baseDir.exists() == false) {
			baseDir.mkdirs();
		}
		// ��ʼ����־·��
		logDir = new File(Environment.getExternalStorageDirectory()
				+ "/community/log");
		if (logDir.exists() == false) {
			logDir.mkdirs();
		}
		
		//���ʹ�����־��������
				Thread.setDefaultUncaughtExceptionHandler(MyExceptionHandler
						.getInstance(getApplicationContext()));
				// ���쳣��Ϣ���͵�������
				if (logDir.listFiles() != null && logDir.listFiles().length > 0)
				{
					new Thread()
					{
						public void run()
						{
							String url = getResources().getString(R.string.base_url)
									+ "file/upload_file.do";
							File[] files = logDir.listFiles();
							for (int i = 0; i < files.length; i++)
							{
								String result = UploadUtil.uploadFile(url,
										files[i].getAbsolutePath(), files[i].getName());
								
								if (result.indexOf("success") == 0)
								{
									
									files[i].delete();
								}
							}
						}
					}.start();
				}

		// ��ʼ������·��
		tmpDir = new File(Environment.getExternalStorageDirectory()
				+ "/community/tmp");
		if (tmpDir.exists() == false) {
			tmpDir.mkdirs();
		}
		// ��ʼ��ͼƬ����·��
		imgTmpDir = new File(Environment.getExternalStorageDirectory()
				+ "/community/tmp/img");
		if (imgTmpDir.exists() == false) {
			imgTmpDir.mkdirs();
		}

		context = this.getApplicationContext();// ��ȡ��ǰ������
		if (sp == null) {
			sp = context.getSharedPreferences("user", MODE_PRIVATE);
		}
		setAdFlag(false);//ÿ���˳������ٽ��붼Ҫ���¼��ع��
		checkLogin();
	}

	public static Users getUser() {
		return user;
	}

	public static void setUser(Users u) {
		user = u;
	}

	public static void logoutUser() {
		user = null;
	}

	public static void setObject(Object object) {
		CommunityApp.object = object;
	}

	public static String getUserId() {
		return user.getId();
	}

	public static void setUserId(String userId) {
		user.setId(userId);
	}
	public static void setUserName(String userName) {
		user.setName(userName);
	}

	public static void setAdFlag(boolean adFlag) {
		AdFlag = adFlag;
	}
	public static boolean getAdFlag(){
		return AdFlag;
	}

	@SuppressLint("ShowToast")
	private void checkLogin() {
		// TODO Auto-generated method stub
//		if (!MyOperation.IsNetConnection(this)) {
//			Toast.makeText(getApplicationContext(), "���ӷ�����ʧ��,��������", Toast.LENGTH_LONG).show();
//			return;
//		}
		final String name = sp.getString("name", null);
		final String id = sp.getString("id", null);
		final String pwd=sp.getString("password", null);
		if (name == null||id==null||pwd==null) {
			// System.out.println("nameΪ��");
			// ��δ��¼���Ѿ�ע����¼��������δ�洢��¼��Ϣ
			sp.edit().clear().commit();
			return;
		}
		user = new Users();
		user.setName(name);
		user.setPwd(pwd);
		user.setId(id);
	}

}
