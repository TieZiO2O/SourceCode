package cn.edu.nciae.community;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.personal.R;

public class Property_CommonNoteActivity extends Activity {
	TextView tvTitle,tvContent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.property_commonnote_info);
		tvTitle=(TextView) findViewById(R.id.wuye_public_xiangxi_title);
		tvContent=(TextView) findViewById(R.id.wuye_public_xiangxi_content);

		Bundle bundle=this.getIntent().getExtras();
		String title=bundle.getString("title");
		String time=bundle.getString("time");
		String content=bundle.getString("content");

		tvTitle.setText(title+"--"+time);
		tvContent.setText("    "+content);

	}

	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
