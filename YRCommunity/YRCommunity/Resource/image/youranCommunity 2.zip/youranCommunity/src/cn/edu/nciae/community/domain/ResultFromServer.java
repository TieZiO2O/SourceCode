package cn.edu.nciae.community.domain;

public class ResultFromServer {
	private boolean IsSuccess;
	private String ResultStr;
	private Users UserInfo;
	private Property property;
	
	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	public String getResultStr() {
		return ResultStr;
	}

	public void setResultStr(String resultStr) {
		ResultStr = resultStr;
	}

	public boolean isIsSuccess() {
		return IsSuccess;
	}

	public void setIsSuccess(boolean isSuccess) {
		IsSuccess = isSuccess;
	}

	public Users getUserInfo() {
		return UserInfo;
	}

	public void setUserInfo(Users userInfo) {
		UserInfo = userInfo;
	}

}
