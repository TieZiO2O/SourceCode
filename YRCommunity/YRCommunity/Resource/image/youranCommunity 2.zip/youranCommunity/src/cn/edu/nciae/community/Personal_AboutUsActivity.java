package cn.edu.nciae.community;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyToast;

import com.example.personal.R;

public class Personal_AboutUsActivity extends Activity {
	RelativeLayout personal_about_title_back_rl;
	TextView version;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_about_us);
		version=(TextView)findViewById(R.id.tvVersion);
		version.setText("��Ȼ������v"+MyOperation.getVersion(getApplicationContext()));
	}

	public void dianzan(View view) {
		if (!MyOperation.IsNetConnection(Personal_AboutUsActivity.this)) {
			Toast.makeText(getApplicationContext(), "�������������⣬�����Ӻ�����", 0).show();
			return;
		}
		Toast.makeText(getApplicationContext(), "��л���Ĺ�����", 0).show();
		finish();
	}

	public void tucao(View view) {
		if (!MyOperation.isLogin()) {
			Intent intent = new Intent(Personal_AboutUsActivity.this,
					Personal_LoginActivity.class);
			startActivity(intent);
			new MyToast(getApplicationContext(), "��ܰ����", "���ȵ�¼", Toast.LENGTH_SHORT);
			return;
		}
		Intent intent = new Intent(getApplicationContext(),
				Personal_MySuggestionActivity.class);
		startActivity(intent);
	}

	  public void onBackImageClick(View view)
	    {
	    	finish();
	    }
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {
			// ���¼����Ϸ��ذ�ť
			if (keyCode == KeyEvent.KEYCODE_BACK) {
				finish();
				return true;

			} else {

				return super.onKeyDown(keyCode, event);

			}

		}
}
