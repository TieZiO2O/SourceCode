package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyDialog;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.mycustom.MyToast;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.CipherUtil;

import com.example.personal.R;

public class Personal_RegisterActivity extends Activity {
	Button butt_register_register;
	RelativeLayout rlayout_register_back;
	EditText edit_register_username, edit_register_userpwd,
			edit_register_userRePwd;

	private final Handler handler = new Handler();
	MyDialog dialog=null;

	@Override
	@SuppressLint("ShowToast")
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_register);
		butt_register_register = (Button) findViewById(R.id.register_register_butt);
		rlayout_register_back = (RelativeLayout) findViewById(R.id.personal_register_title_back_rl);
		edit_register_username = (EditText) findViewById(R.id.register_username_edit);
		edit_register_userpwd = (EditText) findViewById(R.id.register_userpwd_edit);
		edit_register_userRePwd = (EditText) findViewById(R.id.register_userphone_edit);
		dialog=new MyDialog(Personal_RegisterActivity.this);
		changeBack();
		rlayout_register_back.setOnClickListener(new OnClickListener() {// ���ذ�ť
					@Override
					public void onClick(View v) {
						finish();
					}
				});
		// ���ע�ᰴť
		butt_register_register.setOnClickListener(new OnClickListener() {// ע�ᰴť

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						final String name = edit_register_username.getText()
								.toString().trim();
						final String pwd = edit_register_userpwd.getText()
								.toString().trim();
						String rePwd = edit_register_userRePwd.getText()
								.toString().trim();
						if (judge(name, pwd, rePwd)) {
							// ��������ύ����
							final String Md5Pwd=CipherUtil.generatePassword(pwd);
							
							
							MyProgressDialog.startProgressDialog(Personal_RegisterActivity.this, "�����ύ");
							new Thread() {
								@Override
								public void run() {
									try {
										HttpPost httpPost = new HttpPost(
												getResources().getString(
														R.string.base_url)
														+ "member/member_regist.do");
										ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
										NameValuePair nameValuePair = new BasicNameValuePair(
												"username", name);
										nvs.add(nameValuePair);
										nameValuePair = new BasicNameValuePair(
												"password", Md5Pwd);
										nvs.add(nameValuePair);
										httpPost.setEntity(new UrlEncodedFormEntity(
												nvs, "UTF-8"));
										final String result = Httphelper
												.getValueFromNet(httpPost);
										if (result.indexOf("success") == 0) {
											handler.post(new Runnable() {

												@Override
												public void run() {
													// TODO Auto-generated
													MyProgressDialog.stopProgressDialog();
//													Toast.makeText(
//															Personal_RegisterActivity.this,
//															"ע��ɹ�", 0).show();
													Intent intent = new Intent();
													intent.putExtra("name",
															name);
													intent.putExtra("pwd", pwd);
													setResult(RESULT_OK, intent);
													Personal_RegisterActivity.this
															.finish();
												}
											});
										} else if (result.indexOf("failed") == 0) {
											handler.post(new Runnable() {
												@Override
												public void run() {
													MyProgressDialog.stopProgressDialog();
//													Toast.makeText(
//															Personal_RegisterActivity.this,
//															"ע��ʧ�ܣ��û����Ѵ���", 0)
//															.show();
													dialog.SetMydialog1("����", "ע��ʧ��\n���û�����ע��");
													dialog.show();
												}
											});
										}
									} catch (Exception e) {
										MyProgressDialog.stopProgressDialog();
										System.out.println(e.toString());
									}
								};
							}.start();
						}
					}
				});
	}

	// *********************************ע���ж�***************************
	private boolean judge(String name, String pwd, String rePwd) {
		// TODO Auto-generated method stub
		if (name.equals("") || pwd.equals("") || rePwd.equals("")) {
			new MyToast(getApplicationContext(), "��ʾ", "����д������Ϣ", Toast.LENGTH_SHORT);
		} else if (!pwd.equals(rePwd)) {
			new MyToast(getApplicationContext(), "��ʾ", "�������벻һ��", Toast.LENGTH_SHORT);
		} else if (!MyOperation.judgeName(name).equals("")) {
			new MyToast(getApplicationContext(), "��ʾ", MyOperation.judgeName(name), Toast.LENGTH_SHORT);
		} else if (!MyOperation.judegPwd(pwd).equals("")) {
			new MyToast(getApplicationContext(), "��ʾ", MyOperation.judegPwd(pwd), Toast.LENGTH_SHORT);
		} else {
			return true;
		}
		return false;
	}

	public void changeBack() {// �༭��仯
		edit_register_username
				.setOnFocusChangeListener(new OnFocusChangeListener() {

					@Override
					public void onFocusChange(View v, boolean hasFocus) {
						if (hasFocus) {
							edit_register_username
									.setBackgroundResource(R.drawable.personal_reg_edit_selected);
						} else {
							edit_register_username
									.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
						}

					}
				});
		edit_register_userpwd
				.setOnFocusChangeListener(new OnFocusChangeListener() {
					@Override
					public void onFocusChange(View v, boolean hasFocus) {
						if (hasFocus) {
							edit_register_userpwd
									.setBackgroundResource(R.drawable.personal_reg_edit_selected);
						} else {
							edit_register_userpwd
									.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
						}
					}
				});
		edit_register_userRePwd
				.setOnFocusChangeListener(new OnFocusChangeListener() {
					@Override
					public void onFocusChange(View v, boolean hasFocus) {
						if (hasFocus) {
							edit_register_userRePwd
									.setBackgroundResource(R.drawable.personal_reg_edit_selected);
						} else {
							edit_register_userRePwd
									.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
						}
					}
				});
	}
}
