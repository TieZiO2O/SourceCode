package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import cn.edu.nciae.community.adapter.ShopAdapter;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.Merchants;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.domain.ShopImg;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.mycustom.RefreshableView;
import cn.edu.nciae.community.mycustom.RefreshableView.PullToRefreshListener;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.JsonUtil;

import com.example.personal.R;

public class Personal_MyCollectionActivity extends Activity {

	private ListView lv;
	private ArrayList<Merchants> shopsimples = null;
	RefreshableView refreshableView;
	private ShopAdapter adapter;
	private final Handler handler = new Handler();
	private boolean isSrolling;
	private volatile boolean isLoadedOk = false;
	private boolean isLoadImageOk = false;
	private boolean isFirstEnter = true;
	private int curFirst = -1;
	String FLAG = "from_personal_mycollection";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.person_collect);
		refreshableView = (RefreshableView) findViewById(R.id.refreshable_view);
		//����ˢ���¼�
		refreshableView.setOnRefreshListener(new PullToRefreshListener() {

			@Override
			public void onRefresh() {
				// TODO Auto-generated method stub
				getShopinfo();
			}
		}, 0);

		lv = (ListView) findViewById(R.id.lv_select_shop);
		getShopinfo();
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// �����б��¼�����
				// ��shopId �����ҵ��̼���������

				Merchants shopsimple = shopsimples.get(position);
				final String shopId = shopsimple.getId();
				final String realName = shopsimple.getRealName();
				final String shopLogo = shopsimple.getShopLogo();
				final ArrayList<ShopImg> listImgs = shopsimple.getImgUrl();
				final ArrayList<String> urls = new ArrayList<String>();
				final String phone = shopsimple.getPhone();

				for (ShopImg shopImg : listImgs) {
					urls.add(shopImg.getImgUrl());
				}

				final String userId = CommunityApp.getUser().getId();
				if (shopId != null && shopId.length() > 0) {
					Intent intent = new Intent(
							MainActivity.instance,
							Business_InfoActivity.class);

					Bundle bundle = new Bundle();
					bundle.putString("id", shopId);// ���̼�id
					bundle.putString("name", realName);// ���̼�����
					/*
					 * bundle.putString("address",
					 * address);// ���̼ҵ�ַ
					 */try {
						 bundle.putString(
								 "image",
								 getResources().getString(
										 R.string.base_url)
										 + shopLogo
										 .substring(1));// ���̼�ͷ��
					 } catch (Exception e) {
						 bundle.putString("image", null);// ���̼�ͷ��
					 }
					 bundle.putString("phone", phone);// ���̼ҵ绰
					 
					  bundle.putStringArrayList("images",
					  urls);// ���̼�������Ƭ
					  /* bundle.putString("cusKnow"
					  * ,customerNotice);// ���û���֪
					  * 
					  * bundle.putString("info",shopInfoString
					  * );// ���̼���Ʒ��Ϣ
					  */bundle.putString("flag", FLAG);

					  // System.out.println("���bundle----"+bundle.getString(phone));
					  intent.putExtras(bundle);
					  startActivity(intent);
				} else {
					Toast.makeText(MainActivity.instance, "������˯����...", 0)
					.show();
				}
			}
		});

		lv.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {

				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_FLING:
					// ���ڹ���
					isSrolling = true;
					break;
				case OnScrollListener.SCROLL_STATE_IDLE:
					// ��������
					// ��ȡlv ��ʾ�ĵ�һ���ɼ���Ŀ��Index
					isSrolling = false;
					break;
				case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
					break;
				}
			}

			// �Ƿ��ѻ������
			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {

				if (totalItemCount <= 0) {
					return;
				}
				if (curFirst != firstVisibleItem) {

					if (firstVisibleItem == 0) {
						isLoadImageOk = false;
						// loadImage();
					} else if (firstVisibleItem + visibleItemCount == totalItemCount) {
						if (isLoadedOk && isSrolling == false) {
							isLoadImageOk = false;
							// loadImage();
						}
					}
					curFirst = firstVisibleItem;
				}
			}

		});

	}

	// ��ȡ�����ղ�
	public void getShopinfo() {
		if (isLoadedOk) {
			return;
		}
		if (isFirstEnter) {
			MyProgressDialog.startProgressDialog(Personal_MyCollectionActivity.this, null);
			isFirstEnter=false;
		}
		new Thread() {
			@Override
			public void run() {
				// while (CommunityApp.getUserId() == null);
				try {
					HttpPost httpPost = new HttpPost(getResources().getString(
							R.string.base_url)
							+ "member/selectcollection.do");

					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair(
							"memberid", CommunityApp.getUserId());
					nvs.add(nameValuePair);

					httpPost.setEntity(new UrlEncodedFormEntity(nvs, "UTF-8"));
					String resultString = Httphelper.getValueFromNet(httpPost);

					Merchants[] shops = JsonUtil
							.gsonToShopSimple(resultString);
					shopsimples = null;
					shopsimples = new ArrayList<Merchants>();
					int len = shops.length;

					if (len==0) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								MyProgressDialog.stopProgressDialog();
								refreshableView.finishRefreshing();
								adapter = new ShopAdapter(MainActivity.instance,
										shopsimples, lv);
								adapter.setShops(null);
								adapter.notifyDataSetChanged();
								lv.setAdapter(adapter);
								Toast.makeText(getApplicationContext(),
										"����δ�κ��ղ�", 0).show();
							}
						});
						return;
					}

					for (int i = 0; i < len; i++) {
						shopsimples.add(shops[i]);
					}
					handler.post(new Runnable() {

						@Override
						public void run() {
							MyProgressDialog.stopProgressDialog();
							refreshableView.finishRefreshing();
							adapter = new ShopAdapter(MainActivity.instance,
									shopsimples, lv);
							adapter.setShops(shopsimples);
							adapter.notifyDataSetChanged();
							lv.setAdapter(adapter);
						}
					});
					//isLoadedOk = true;
				} catch (Exception e) {
					//isLoadedOk = false;
					e.printStackTrace();
					handler.post(new Runnable() {
						@Override
						public void run() {
							MyProgressDialog.stopProgressDialog();
							refreshableView.finishRefreshing();
							if (!MyOperation.IsNetConnection(getApplicationContext())) {
								Toast.makeText(getApplicationContext(), "��ȡ����ʧ�ܣ��������������", Toast.LENGTH_SHORT).show();
								return;
							}
							Toast.makeText(getApplicationContext(),
									"���ӷ�����ʧ�ܣ����Ժ�����", 0).show();
						}
					});
				}
			}
		}.start();
	}
	
	public void back(View view) {
		this.finish();
	}
	
	@Override
	protected void onRestart() {
		isFirstEnter=true;
		getShopinfo();
		super.onRestart();
	}
}
