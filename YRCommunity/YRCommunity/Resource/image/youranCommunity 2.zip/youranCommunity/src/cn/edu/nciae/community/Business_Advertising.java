package cn.edu.nciae.community;

import com.example.personal.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Business_Advertising extends Activity{
	LinearLayout shangjia_xiangxi_shoucang_ll;
	RelativeLayout main_personal_about;
	ImageView shangjia_xiangxi_imageview;
	TextView shangjia_xiangxi_textview,shangjia_xiangxi_shangpin_info,shangjia_xiangxi_cus_know,shangjia_xiangxi_address;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.business_info);
		shangjia_xiangxi_shoucang_ll=(LinearLayout) findViewById(R.id.shangjia_xiangxi_shoucang_ll);
		main_personal_about=(RelativeLayout) findViewById(R.id.main_personal_about);
		shangjia_xiangxi_imageview=(ImageView) findViewById(R.id.shangjia_xiangxi_imageview);
		shangjia_xiangxi_textview=(TextView) findViewById(R.id.shangjia_xiangxi_textview);
		shangjia_xiangxi_shangpin_info=(TextView) findViewById(R.id.shangjia_xiangxi_shangpin_info);
		shangjia_xiangxi_cus_know=(TextView) findViewById(R.id.shangjia_xiangxi_cus_know);
		shangjia_xiangxi_address=(TextView) findViewById(R.id.shangjia_xiangxi_address);
		UIoperate();
	}
	void UIoperate()
	{
		shangjia_xiangxi_shoucang_ll.setVisibility(4);
	}
	//��ת��ͼ���������
	public void shangjia_xiangxi_tuwen(View view)
	{
		//new MyToast(getApplicationContext(), "ͼ������", "ͼ������", 200);
		Intent intent=new Intent(this,Business_ImagesWitcherActivity.class);
		startActivity(intent);
	}
	//�����̼ҵ绰
	public void shangjia_xiangxi_cell(View view)
	{
		Intent callIntent = new Intent(Intent.ACTION_CALL);
		callIntent.setData(Uri.parse("tel:15631610301"));
		startActivity(callIntent);
	}
	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
