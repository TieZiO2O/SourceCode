package cn.edu.nciae.community.city;

public class ContactItemException extends Exception
{

	public ContactItemException()
	{
	}

	public ContactItemException(String msg)
	{
		super(msg);
	}

}
