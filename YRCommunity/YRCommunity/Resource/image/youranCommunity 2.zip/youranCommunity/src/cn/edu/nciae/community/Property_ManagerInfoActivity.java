package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyDialog;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.mycustom.MyToast;
import cn.edu.nciae.community.net.Httphelper;

import com.example.personal.R;

public class Property_ManagerInfoActivity extends Activity {
	private Button property_info_call_butt, property_info_suggestion_butt;
	private ImageView iv_property_log;
	private TextView tv_property_name;
	private TextView tv_property_phone;
	private TextView tv_priperty_address;
	private TextView tv_property_detail_info;
	final Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.property_info);
		SharedPreferences sp = getSharedPreferences("myCityCommunity",
				MODE_PRIVATE);
		String communityid = sp.getString("communityId", null);
		property_info_call_butt = (Button) findViewById(R.id.property_info_call_butt);
		iv_property_log = (ImageView) findViewById(R.id.iv_property_logo);
		tv_property_name = (TextView) findViewById(R.id.tv_property_name);
		tv_property_phone = (TextView) findViewById(R.id.tv_property_phone);
		tv_priperty_address = (TextView) findViewById(R.id.tv_priperty_address);
		tv_property_detail_info = (TextView) findViewById(R.id.tv_property_detail_info);
		property_info_suggestion_butt = (Button) findViewById(R.id.property_info_suggestion_butt);

		getPropertyInfo(communityid);

		property_info_call_butt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Dialog dialog = null;
				MyDialog.Builder customBuilder = new
						MyDialog.Builder(Property_ManagerInfoActivity.this);
				customBuilder.setTitle("����")
				.setMessage("�Ƿ񲦴���ҵ�绰��")
				.setNegativeButton("ȡ��", 
						new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				})
				.setPositiveButton("ȷ��", 
						new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						if (tv_property_phone.length() != 0) {
							Intent callIntent = new Intent(Intent.ACTION_CALL);
							callIntent.setData(Uri.parse("tel:"
									+ tv_property_phone.getText().toString()));
							startActivity(callIntent);
						} else {
							Toast.makeText(getBaseContext(), "û�п�ʹ�õĺ���", 0).show();
						}
					}
				});
				dialog = customBuilder.create();
				dialog.show();
			}
		});
		property_info_suggestion_butt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!MyOperation.isLogin()) {
					Intent intent = new Intent(getApplicationContext(),
							Personal_LoginActivity.class);
					startActivity(intent);
					new MyToast(getApplicationContext(), "��ܰ����", "���ȵ�¼", Toast.LENGTH_SHORT);
					return;
				}
				Intent intent = new Intent(getApplicationContext(),
						Property_MySuggestionActivity.class);
				startActivity(intent);
			}
		});
	}
	// ��ȡ��ҵ��Ϣ
		private void getPropertyInfo(String propertyid) {

			if (!MyOperation.IsNetConnection(this)) {
				Toast.makeText(getApplicationContext(), "��ȡ����ʧ�ܣ��������������", Toast.LENGTH_SHORT).show();
				return;
			}
			
			final String propertyId = propertyid;
			//System.out.println("xiaoqude----------id" + propertyId);
			MyProgressDialog.startProgressDialog(Property_ManagerInfoActivity.this, null);
			new Thread() {
				@SuppressWarnings("unused")
				@Override
				@SuppressLint("ShowToast")
				public void run() {
					try {
						HttpPost httpPost = new HttpPost(getResources().getString(
								R.string.base_url)
								+ "member/mem_selectpropertyinfo.do");
						ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
						NameValuePair nameValuePair = new BasicNameValuePair(
								"propertyid", propertyId);
						nvs.add(nameValuePair);

						httpPost.setEntity(new UrlEncodedFormEntity(nvs, "utf-8"));
						final String resultString = Httphelper
								.getValueFromNet(httpPost);
						System.out.println("����С����Ϣ�Ĳ�ѯ���--------" + resultString);
						
						try {
							JSONObject jsonObj = new JSONObject(resultString)
									.getJSONObject("property");
							String id = jsonObj.getString("id");
							final String phone = jsonObj.getString("phone");
							final String aboutUs = jsonObj.getString("aboutUs");
							final String address = jsonObj.getString("address");
							final String realName = jsonObj.getString("realName");
							String shopLogo = jsonObj.getString("shopLogo");
							handler.post(new Runnable() {
								
								@Override
								public void run() {
									MyProgressDialog.stopProgressDialog();
									tv_property_name.setText(realName);
									tv_property_phone.setText(phone);
									tv_priperty_address.setText(address);
									tv_property_detail_info.setText(aboutUs);
								}
							});
						

						} catch (JSONException e) {
							System.out.println("Json parse error");
							handler.post(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									MyProgressDialog.stopProgressDialog();
								}
							});
							e.printStackTrace();
						}
					} catch (Exception e) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								MyProgressDialog.stopProgressDialog();
								Toast.makeText(getApplicationContext(),
										"���ӷ�����ʧ�ܣ����Ժ�����...", 0).show();
							}
						});
					}
				}
			}.start();

		}

	// ����ͼƬ��ť�����
	public void onBackImageClick(View view) {
		finish();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {
			return super.onKeyDown(keyCode, event);

		}

	}
}
