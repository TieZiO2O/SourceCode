package cn.edu.nciae.community.adapter;

import java.util.ArrayList;
import java.util.List;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class FragmentPageAdapter extends FragmentStatePagerAdapter {

	private List<Fragment> listFragment = new ArrayList<Fragment>();

	public FragmentPageAdapter(FragmentManager fm) {//���캯��
		super(fm);
	}

	public void setListFragment(List<Fragment> listFragment) {
		this.listFragment = listFragment;
	}

	@Override
	public Fragment getItem(int arg0) {
		return listFragment.get(arg0);
	}

	@Override
	public int getCount() {
		return listFragment.size();
	}

}
