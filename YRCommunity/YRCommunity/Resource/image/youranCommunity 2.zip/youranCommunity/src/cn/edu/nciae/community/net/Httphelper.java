package cn.edu.nciae.community.net;

import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class Httphelper {

	// �ӷ�������ȡ��Ϣ method ��Ӧ�ð�������Ϣ:
	// url,���ݸ��������Ĳ���
	static int timeout=5000;
	public static String getValueFromNet(HttpRequestBase method)
			throws Exception {
		
		StringBuilder sb = new StringBuilder();

		HttpClient client = new DefaultHttpClient();
		HttpParams httpParams = client.getParams();
		// �������糬ʱ����
		HttpConnectionParams.setConnectionTimeout(httpParams, timeout);
		HttpConnectionParams.setSoTimeout(httpParams, timeout);
		httpParams.setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET,
				"UTF-8");
		HttpResponse response = client.execute(method);

		if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
			// ���ӳɹ�
			HttpEntity entity = response.getEntity();

			if (entity != null) {
				InputStream is = entity.getContent();
				InputStreamReader isr = new InputStreamReader(is,"UTF-8");
				int len = 0;
				char[] buf = new char[1024 * 4];
				while (true) {
					len = isr.read(buf);
					if (len == -1) {
						break;
					}
					sb.append(new String(buf, 0, len));
				}
				isr.close();
				is.close();
			}
		} else {
			// ����ʧ��
			throw new Exception("connect error");
		}
		return sb.toString();
	}

}
