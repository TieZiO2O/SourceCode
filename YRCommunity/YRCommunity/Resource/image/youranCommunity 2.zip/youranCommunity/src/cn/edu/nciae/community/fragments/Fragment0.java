package cn.edu.nciae.community.fragments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import cn.edu.nciae.community.Property_Convenience_Info;
import cn.edu.nciae.community.mycustom.ListViewForScrollView;

import com.example.personal.R;

public class Fragment0 extends Fragment {

	private View view;
	// ��ҵListView
	ListViewForScrollView main_wuye_liebiao_list;
	SimpleAdapter listItemAdapter;

	int[] list_image = { R.drawable.kaixin, R.drawable.shenghuo};
	String[] list_text = { "����һ��", "���ʶ" };
	String[] list_nametext={"ЦһЦ��ʮ����","�����ߣ���ʮ��"};
	LinearLayout main_wuye_message_lin, main_wuye_notice_lin;
	ScrollView sv;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.main_property, container, false);
		sv = (ScrollView) view.findViewById(R.id.main_wuye_scrollview);
		sv.setVerticalScrollBarEnabled(false);
		main_wuye_liebiao_list = (ListViewForScrollView) view
				.findViewById(R.id.main_wuye_liebiao_list);
		sv.smoothScrollTo(0, 0);
		operateListView();
		return view;
	}

	private void operateListView() {
		listItemAdapter = new SimpleAdapter(getActivity(), getData(list_image,
				list_text), R.layout.property_list_listitem, new String[] {
			"list_image", "list_text","list_nametext" }, new int[] {
			R.id.wuye_list_listitem_name_image,
			R.id.wuye_list_listitem_name_text ,
			R.id.wuye_list_listitem_nametext_text});
		main_wuye_liebiao_list.setAdapter(listItemAdapter);
		main_wuye_liebiao_list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
//				Toast.makeText(getActivity(), ""+position, 0).show();
				Intent intent=new Intent(getActivity(),Property_Convenience_Info.class);
				intent.putExtra("convenience_position", position);
				startActivity(intent);
			}
		});
	}

	private List<Map<String, Object>> getData(int list_image[],
			String list_text[]) {
		ArrayList<Map<String, Object>> listitem = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < list_image.length; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("list_image", list_image[i]);
			map.put("list_text", list_text[i]);
			map.put("list_nametext", list_nametext[i]);
			listitem.add(map);
		}
		return listitem;
	}
}
