package cn.edu.nciae.community.domain;

import com.example.personal.R;

public class Convenience {
	private int position;
	int Image0[] = { R.drawable.happy1, R.drawable.happy2, R.drawable.happy3,
			R.drawable.happy4, R.drawable.happy5, R.drawable.happy6,
			R.drawable.happy7, R.drawable.happy8, R.drawable.happy9,
			R.drawable.happy10 };
	int Image1[] = { R.drawable.live1, R.drawable.live2, R.drawable.live3,
			R.drawable.live4, R.drawable.live5, R.drawable.live6,
			R.drawable.live7, R.drawable.live8, R.drawable.live9,
			R.drawable.live10 };

	private String id;// �������id
	private String convenienceName;// �����������
	private String convenienceText;// �����������

	public Convenience(int position) {
		this.position = position;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getConvenienceName() {
		return convenienceName;
	}

	public void setConvenienceName(String convenienceName) {
		this.convenienceName = convenienceName;
	}

	public String getConvenienceText() {
		return convenienceText;
	}

	public void setConvenienceText(String convenienceText) {
		this.convenienceText = convenienceText;
	}

	public int getConvenienceImage() {
		int index = (int) (Math.random() * 10);
		if (this.position == 0)
			return Image0[index];
		else
			return Image1[index];
	}
}
