package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.net.Httphelper;

import com.example.personal.R;

public class Personal_MySuggestionActivity extends Activity {

	private final Handler handler = new Handler();
	EditText et_personal_my_suggestion;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_suggestion);
		et_personal_my_suggestion = (EditText) findViewById(R.id.personal_suggestion_et);
	}

	public void submit(View view) {
		
		if (et_personal_my_suggestion.getText().length() != 0) {
			if (!MyOperation.IsNetConnection(Personal_MySuggestionActivity.this)) {
				Toast.makeText(getApplicationContext(), "���ӷ�����ʧ�ܣ����������", 0).show();
				return;
			}
			String mysuggestion = et_personal_my_suggestion.getText()
					.toString().trim();
			submmitMySuggestion(mysuggestion);
		} else {
			Toast.makeText(getApplicationContext(), "���ݲ���Ϊ�գ�", 0).show();
		}

	}

	public void submmitMySuggestion(String Suggestion) {

		final String suggestion = Suggestion;
		MyProgressDialog.startProgressDialog(Personal_MySuggestionActivity.this, null);
		new Thread() {
			@Override
			public void run() {
				try {
					HttpPost httpPost = new HttpPost(getResources().getString(
							R.string.base_url)
							+ "member/insertcomment.do");
					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair("memid",
							CommunityApp.getUserId());
					nvs.add(nameValuePair);
					nameValuePair = new BasicNameValuePair("msg",
							suggestion);
					nvs.add(nameValuePair);
					httpPost.setEntity(new UrlEncodedFormEntity(nvs, "utf-8"));
					final String result = Httphelper.getValueFromNet(httpPost);
					// System.out.println(result);
					if (result.indexOf("success") == 0) {

						handler.post(new Runnable() {

							@Override
							public void run() {
								MyProgressDialog.stopProgressDialog();
								Toast.makeText(getBaseContext(), "��л���ķ���", 0)
										.show();
								Personal_MySuggestionActivity.this.finish();
							}
						});
					} else if (result.indexOf("failed") == 0) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								MyProgressDialog.stopProgressDialog();
								Toast.makeText(getBaseContext(), "�Բ��𣬷������°�����",
										0).show();
							}
						});
					}

				} catch (Exception e) {
					e.printStackTrace();
					handler.post(new Runnable() {
						@Override
						public void run() {
							MyProgressDialog.stopProgressDialog();
							Toast.makeText(CommunityApp.context,
									"������ȥ���ǿ�����...", 0).show();
						}
					});
				}
			}

		}.start();

	}

	// ����ͼƬ��ť�����
	public void onBackImageClick(View view) {
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
		finish();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			getWindow().setSoftInputMode(
					WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
