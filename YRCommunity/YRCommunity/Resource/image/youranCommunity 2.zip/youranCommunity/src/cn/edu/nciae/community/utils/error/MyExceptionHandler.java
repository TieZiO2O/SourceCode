package cn.edu.nciae.community.utils.error;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.reflect.Field;
import java.sql.Date;
import java.text.SimpleDateFormat;

import cn.edu.nciae.community.app.CommunityApp;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.widget.Toast;

public class MyExceptionHandler implements UncaughtExceptionHandler {

	private static MyExceptionHandler mHandler;
	private static Context mContext;
	private MyExceptionHandler(){}
	public synchronized static MyExceptionHandler getInstance(Context context){
		if(mHandler==null){
			mHandler = new MyExceptionHandler();
			mContext = context;
		}
		return mHandler;
	}

	@Override
	public void uncaughtException(Thread arg0, Throwable ex) {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			System.out.println("������Ϣ" + sw.toString());
			File file = new File(Environment.getExternalStorageDirectory()+"/AAA");
			if(file.exists()==false){
				file.mkdir();
			}
			file=new File(CommunityApp.logDir,"err"+new SimpleDateFormat("_yyyy_MM_dd_HH_mm_dd").format(new Date(System.currentTimeMillis()))+".txt");
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(("time:"+System.currentTimeMillis()+"\n").getBytes());
			fos.flush();

			fos.write(sw.toString().getBytes());
			fos.flush();

			// ��ȡ�ֻ��İ汾��
			Field[] fields = Build.class.getFields();
			for (Field field : fields) {
				field.setAccessible(true); // ��������
				String key = field.getName();
				String value = field.get(null).toString();

				fos.write((key+"="+value+"\n").getBytes());
				fos.flush();
			}

			new Thread(){
				public void run() {
					Looper.prepare();
					Toast.makeText(mContext, "��������쳣", 0).show();
					Looper.loop();
				}
			}.start();
			new Thread(){
				public void run() {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					android.os.Process.killProcess(android.os.Process.myPid());
				};
			}.start();
			fos.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
