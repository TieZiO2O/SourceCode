package cn.edu.nciae.community;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.mycustom.MyProgressDialog;

import com.example.personal.R;

public class Personal_SettingInfoActivity extends Activity {

	SharedPreferences sp;
	TextView tvname;
	private final Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_manage);

		tvname = (TextView) findViewById(R.id.personal_manage_name_tv1);

		sp = getSharedPreferences("user", MODE_PRIVATE);
		tvname.setText("�û�����" + sp.getString("name", ""));
	}
	// �޸�����
	public void changepwd(View view) {
		Intent intent=new Intent(Personal_SettingInfoActivity.this,Personal_Modify_PasswordActivity.class);
		startActivity(intent);
	}
    public void changename(View view)
    {
    	Intent intent=new Intent(Personal_SettingInfoActivity.this,Personal_ChangeNameActivity.class);
		startActivity(intent);
    }
	// �˳���¼
	@SuppressLint("ShowToast")
	public void exitlogin(View view) {
		String idString = sp.getString("id", null);
		if (idString != null) {
			logOut(idString);
		}
	}

	public void logOut(final String id) {
		MyProgressDialog.startProgressDialog(Personal_SettingInfoActivity.this, null);
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					Thread.sleep(2000);
					handler.post(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							CommunityApp.logoutUser();
							sp.edit().clear().commit();
							MyProgressDialog.stopProgressDialog();
							Toast.makeText(getApplicationContext(),
									"���˳���¼", Toast.LENGTH_SHORT).show();
							Personal_SettingInfoActivity.this.finish();
						}
					});
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}
	
	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		tvname.setText("�û�����" + sp.getString("name", ""));
	}
	
	//����ͼƬ��ť�����
    public void onBackImageClick(View view)
    {
    	finish();
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;
		} else {
			return super.onKeyDown(keyCode, event);

		}

	}
}
