package cn.edu.nciae.community.domain;

public class Collection {// �ղ���

	private Integer id;// �ղ�id
	private Integer memId;// �û�id
	private Integer shopperId;// �̼�id

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMemId() {
		return memId;
	}

	public void setMemId(Integer memId) {
		this.memId = memId;
	}

	public Integer getShopperId() {
		return shopperId;
	}

	public void setShopperId(Integer shopperId) {
		this.shopperId = shopperId;
	}
}
