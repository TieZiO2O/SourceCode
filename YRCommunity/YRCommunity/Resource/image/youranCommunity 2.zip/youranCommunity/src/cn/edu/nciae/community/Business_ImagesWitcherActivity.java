package cn.edu.nciae.community;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.mycustom.ImageDownloaderTask;

import com.example.personal.R;


public class Business_ImagesWitcherActivity extends Activity implements OnPageChangeListener {
	String city, home;
	//��װ��������
	ViewPager viewpager;
	int ads[]={R.drawable.ic_launcher,R.drawable.switch2,R.drawable.switch2,R.drawable.switch2};
	List<View> items;
	ImageView dot,dots[];
	ImageView[] imageView=null;
	LinearLayout viewGroup;
	int currentIndex = 0;
	Boolean f = true;
	ImageView firstLogin;
	//ͼƬ����
	ArrayList<String>images=new ArrayList<String>();
	String URL=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.business_imageswitcher);
		URL = getResources().getString(R.string.base_url);// ��ȡ��������ip��ַ
		Intent intent=this.getIntent();
		images=intent.getStringArrayListExtra("images");
		imageView=new ImageView[images.size()];
		initViewPager();
		initDot();

	}
	private void initDot() {
		// TODO Auto-generated method stub
		viewGroup = (LinearLayout)findViewById(R.id.viewGroup);
		dots = new ImageView[items.size()];

		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(20,20);
		layoutParams.setMargins(50, 10, 50, 10);
		for(int i=0 ; i<items.size(); i++){
			dot = new ImageView(this);

			dot.setLayoutParams(layoutParams);  			
			dots[i] = dot;
			dots[i].setTag(i);
			dots[i].setOnClickListener(onClick);

			if (i == 0) {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotc);  
			} else {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotn);  
			}  

			viewGroup.addView(dots[i]);  
		}
		if (items.size()>7) {//����8�žͲ���ʾ���
			viewGroup.setVisibility(View.INVISIBLE);
		}
	}

	//��ʼ��view��ͼ������viewpager��������	
	private void initViewPager() {
		// TODO Auto-generated method stub
		items = new ArrayList<View>();	
		for(int i=0; i<images.size(); i++){
			DisplayMetrics dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
		    int screenHeigh = dm.heightPixels;
			LinearLayout lin = new LinearLayout(this);
			imageView[i]=new ImageView(this);
//			imageView.setImageBitmap(bm);
			imageView[i].setTag(URL+images.get(i).substring(1));//���ñ�־
			imageView[i].setImageResource(R.drawable.switch2);//����Ĭ��ͼƬ
			LayoutParams params=new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			imageView[i].setLayoutParams(params);
			imageView[i].setScaleType(ScaleType.FIT_CENTER);
			//ȥ������
			CommunityApp.object = Business_ImagesWitcherActivity.class;// ����������ת��Activity
			new ImageDownloaderTask<Business_ImagesWitcherActivity>(
					Business_ImagesWitcherActivity.this)
					.execute(new String[] { URL+images.get(i).substring(1) });// ȥSD����������
			
			
			lin.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
			lin.setBackgroundColor(Color.TRANSPARENT);
			lin.setOrientation(LinearLayout.VERTICAL);
			lin.addView(imageView[i]);
//			lin.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
			lin.setGravity(Gravity.CENTER);
			lin.setPadding(0, 0, 0, screenHeigh/25);
			items.add(lin);
		}

		viewpager = (ViewPager)findViewById(R.id.viewpager);
		viewpager.setAdapter(adapter);
		viewpager.setOnPageChangeListener(this);
	}
	// ��SDCard�������ȡͼƬ��Ļص�������֪ͨlistview����
		public void onComplete(String url, Bitmap bitmap) {
			for(int i=0;i<images.size();i++){
				if (imageView[i].getTag().equals(url)) {
					imageView[i].setImageBitmap(bitmap);
					return;
				}
			}
		}

	//ʵ��dot�����Ӧ����
	OnClickListener onClick = new OnClickListener(){

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int position = (Integer)v.getTag();  
			setCurView(position);  
			setCurDot(position);  
		}	

	};

	/** 
	 *���õ�ǰ������ҳ  
	 */  
	private void setCurView(int position)  
	{  
		if (position < 0 || position >= items.size()) {  
			return;  
		}  

		viewpager.setCurrentItem(position); 
		currentIndex = position;  
	}  

	/** 
	 *ѡ�е�ǰ����С��
	 */  
	private void setCurDot(int position)  
	{  
		if (position < 0 || position > items.size() - 1) {  
			return;  
		}  

		dots[position]  
				.setBackgroundResource(R.drawable.dotc);  

		currentIndex = position; 

	}  

	PagerAdapter adapter = new PagerAdapter(){

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return items.size();
		}

		@Override
		public void destroyItem(View container, int position, Object object) {
			// TODO Auto-generated method stub
			((ViewPager) container).removeView(items.get(position));
		}

		@Override
		public Object instantiateItem(View container, int position) {
			// TODO Auto-generated method stub
			((ViewPager) container).addView(items.get(position), 0);
			return items.get(position);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0 == arg1 ;
		}

	};

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageSelected(int arg0) {
		// TODO Auto-generated method stub
		for (int i = 0; i < dots.length; i++) {  
			dots[arg0]  
					.setBackgroundResource(R.drawable.dotc);  
			if (arg0 != i) {  
				dots[i]  
						.setBackgroundResource(R.drawable.dotn);  
			}  
		}  
	}
	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
