package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.fragments.Fragment2;
import cn.edu.nciae.community.mycustom.MyToast;
import cn.edu.nciae.community.net.Httphelper;

import com.example.personal.R;

public class Personal_ChangeNameActivity extends Activity{
	public static final int RES_NAME_OK=1;
	ImageView iv_edit_myinfo_name_clear;
	EditText et_personal_change_name;
	private Button tv_save_personal_change_name;
	private String txtName;
	ProgressBar pb;
	Handler handler=new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_change_name);
		iv_edit_myinfo_name_clear = (ImageView) findViewById(R.id.iv_personal_change_name_clear);
		iv_edit_myinfo_name_clear.setOnClickListener(listener);
		et_personal_change_name = (EditText) findViewById(R.id.et_personal_change_name);
		et_personal_change_name.addTextChangedListener(watcher);
		pb=(ProgressBar)findViewById(R.id.pb_personal_change_name);
		tv_save_personal_change_name=(Button)findViewById(R.id.tv_save_personal_change_name);
		tv_save_personal_change_name.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String name=et_personal_change_name.getText().toString().trim();
				if (name.length()==0) {
					new MyToast(getApplicationContext(), "��ʾ", "����д�û���", Toast.LENGTH_SHORT);
					return;
				}
				if (!MyOperation.judgeName(name).equals("")) {
					new MyToast(getApplicationContext(), "��ʾ", MyOperation.judgeName(name), Toast.LENGTH_SHORT);
					return;
				}
				changeName(name);
			}
		});
	}

	private void changeName(String name) {
		pb.setVisibility(View.VISIBLE);
		final String username=name;
		new Thread() {

			@Override
			public void run() {
				try {
					HttpPost httpPost = new HttpPost(
							getResources().getString(
									R.string.base_url)
									+ "member/member_modifyname.do");

					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair(
							"id",
							CommunityApp.getUserId());
					nvs.add(nameValuePair);
					nameValuePair = new BasicNameValuePair(
							"name",
							username);
					nvs.add(nameValuePair);


					httpPost.setEntity(new UrlEncodedFormEntity(
							nvs, "utf-8"));
					final String result = Httphelper
							.getValueFromNet(httpPost);
					//System.out.println(result);
					if (result.indexOf("success") == 0) {
						SharedPreferences sp = getSharedPreferences(
								"user", MODE_PRIVATE);
						Editor editor = sp.edit();
						editor.putString("name",
								username);
						editor.commit();
						CommunityApp.setUserName(username);
						handler.post(new Runnable() {

							@Override
							public void run() {
								pb.setVisibility(View.INVISIBLE);
								Fragment2 f=new Fragment2();
								f.checkUser();
								Toast.makeText(
										getBaseContext(),
										"�޸ĳɹ�", 0)
										.show();
								Personal_ChangeNameActivity.this
								.finish();
							}
						});
					} else if(result.indexOf("failed") == 0){
						handler.post(new Runnable() {

							@Override
							public void run() {
								pb.setVisibility(View.INVISIBLE);
								Toast.makeText(
										getBaseContext(),
										"�޸�ʧ��",
										0).show();
							}
						});
					}

				} catch (Exception e) {
					e.printStackTrace();
					handler.post(new Runnable() {
						@Override
						public void run() {
							pb.setVisibility(View.INVISIBLE);
							Toast.makeText(
									CommunityApp.context,
									"������ȥ���ǿ�����...", 0)
									.show();
						}
					});
				}
			}
		}.start();

	}

	//�༭��ļ����¼�
	private final TextWatcher watcher = new TextWatcher() {

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
			// TODO Auto-generated method stub

		}
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
			// TODO Auto-generated method stub

		}
		@Override
		public void afterTextChanged(Editable s) {
			if (!et_personal_change_name.getText().equals("")
					|| !et_personal_change_name.getText().equals(null)) {
				iv_edit_myinfo_name_clear.setVisibility(View.VISIBLE);
				txtName=et_personal_change_name.getText().toString().trim();
			}

		}
	};

	// �����¼�
	protected OnClickListener listener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.iv_personal_change_name_clear:
				et_personal_change_name.setText("");
				iv_edit_myinfo_name_clear.setVisibility(View.INVISIBLE);
				break;
			}
		}
	};

	public void back(View view) {
		Intent intnet=new Intent();
		intnet.putExtra("name", txtName);
		setResult(RES_NAME_OK, intnet);
		this.finish();
	}

}
