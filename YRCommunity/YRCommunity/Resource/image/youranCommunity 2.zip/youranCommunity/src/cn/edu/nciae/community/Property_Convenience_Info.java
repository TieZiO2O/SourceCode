package cn.edu.nciae.community;


import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.R.string;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import cn.edu.nciae.community.domain.Convenience;
import cn.edu.nciae.community.domain.DailyAbc;
import cn.edu.nciae.community.domain.HappyMoment;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.GsonUtils;

import com.example.personal.R;

public class Property_Convenience_Info extends Activity{
	TextView titlebar, contenttitle, contenttext;
	ImageView contentImage;
	Convenience convenience;
	int convenience_position;
	int convenienceImage;

	Handler handler=new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.property_convenience_info);


		titlebar=(TextView) findViewById(R.id.property_convenience_info_title_text);
		contenttitle=(TextView) findViewById(R.id.property_convenience_info_name_text);
		contenttext=(TextView) findViewById(R.id.property_convenience_info_nametext_text);
		contentImage=(ImageView) findViewById(R.id.property_convenience_info_name_image);

		Intent intent=getIntent();
		convenience_position=intent.getIntExtra("convenience_position", -1);
		if(convenience_position==0)
			titlebar.setText("����һ��");
		if(convenience_position==1)
			titlebar.setText("���ʶ");
		if (convenience_position==-1) {
			Toast.makeText(Property_Convenience_Info.this, "��Ǹ����������������", Toast.LENGTH_SHORT).show();
			this.finish();
			return;
		}

		getData();//��ȡ����

		if(convenience_position==0)
			convenience=new Convenience(0);
		else
			convenience=new Convenience(1);

		convenienceImage=convenience.getConvenienceImage();
	}
	//�ӷ�������ȡ����
	private void getData() {
		// TODO Auto-generated method stub
		MyProgressDialog.startProgressDialog(Property_Convenience_Info.this, null);
		new Thread() {
			@Override
			public void run() {
				try {
					HttpPost httpPost = null;
					if (convenience_position==0) {//����һ��
						httpPost=new HttpPost(getResources().getString(
								R.string.base_url)
								+ "member/mem_getANewHappyMoment.do");
					}else {//��ʶ
						httpPost=new HttpPost(getResources().getString(
								R.string.base_url)
								+ "member/mem_getANewDailyAbc.do");
					}

					ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
					NameValuePair nameValuePair = new BasicNameValuePair(
							"unUse", "0");
					nvs.add(nameValuePair);

					httpPost.setEntity(new UrlEncodedFormEntity(nvs, "UTF-8"));
					final String result = Httphelper.getValueFromNet(httpPost);
					MyProgressDialog.stopProgressDialog();
					if (convenience_position==0) {//Ц��
						final HappyMoment hm=GsonUtils.gsonToHappy(result)[0];

						handler.post(new Runnable() {

							@Override
							public void run() {
								contenttitle.setText(hm.getTitle());
								contenttext.setText(getsubString(hm.getContent()));
								contentImage.setImageResource(convenienceImage);
							}
						});
					}else {//��ʶ
						final DailyAbc daily=GsonUtils.gsonToDailyABC(result)[0];

						handler.post(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								contenttitle.setText(daily.getTitle());
								contenttext.setText(getsubString(daily.getContent()));
								contentImage.setImageResource(convenienceImage);
							}
						});
					}

				} catch (final Exception e) {
					e.printStackTrace();
					handler.post(new Runnable() {
						@Override
						public void run() {
							MyProgressDialog.stopProgressDialog();
							if (!MyOperation.IsNetConnection(getApplicationContext())) {
								Toast.makeText(getApplicationContext(),
										"���������ӣ����Ժ�����", 0).show();
								return;
							}
							Toast.makeText(getApplicationContext(),
									"���ӷ�����ʧ�ܣ����Ժ�����", 0).show();

						}
					});

				}
			}
		}.start();
	}
    public String getsubString(String s)
    {
    	int j=s.length();
		for(int i=0;i<j;i++)
		{
			char c=s.charAt(i);
			if(c=='#')
			{
				j=i;
				break;
			}
		}
		return s.substring(0,j);
    }
	//����ͼƬ��ť�����
	public void onBackImageClick(View view)
	{
		finish();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
