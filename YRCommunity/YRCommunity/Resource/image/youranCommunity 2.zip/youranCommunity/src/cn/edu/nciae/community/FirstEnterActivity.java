package cn.edu.nciae.community;

import android.app.Activity;
import android.os.Bundle;

public class FirstEnterActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

	}

}
