package cn.edu.nciae.community.mycustom;
import com.example.personal.R;

import android.app.ActionBar.LayoutParams;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
public class MyDialog extends Dialog{
	public static View mView;
	public Boolean clickbuttonBoolean;
	LinearLayout mydialog1_layout_lin,mydialog2_layout_lin;
	Button mydialog2_layout_but1,mydialog2_layout_but2,mydialog1_layout_butt;

	 public MyDialog(Context context, int theme) {
	        super(context, theme);
	    }
	  
	public MyDialog(Context context) {
		super(context,R.style.FullHeightDialog);
		mView = LayoutInflater.from(getContext()).inflate(R.layout.mydialog_layout, null);
		mydialog1_layout_lin=(LinearLayout) mView.findViewById(R.id.mydialog1_layout_lin);
		mydialog2_layout_lin=(LinearLayout) mView.findViewById(R.id.mydialog2_layout_lin);
		super.setContentView(mView);
	}
	public static class Builder {
		  
        private Context context;
        private String title;
        private String message;
        private String positiveButtonText;
        private String negativeButtonText;
        private View contentView;
  
        private DialogInterface.OnClickListener 
                        positiveButtonClickListener,
                        negativeButtonClickListener;
  
        public Builder(Context context) {
            this.context = context;
        }
  
        /**
         * Set the Dialog message from String
         * @param title
         * @return
         */
        public Builder setMessage(String message) {
            this.message = message;
            return this;
        }
  
        /**
         * Set the Dialog message from resource
         * @param title
         * @return
         */
        public Builder setMessage(int message) {
            this.message = (String) context.getText(message);
            return this;
        }
  
        /**
         * Set the Dialog title from resource
         * @param title
         * @return
         */
        public Builder setTitle(int title) {
            this.title = (String) context.getText(title);
            return this;
        }
  
        /**
         * Set the Dialog title from String
         * @param title
         * @return
         */
        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }
  
        /**
         * Set a custom content view for the Dialog.
         * If a message is set, the contentView is not
         * added to the Dialog...
         * @param v
         * @return
         */
        public Builder setContentView(View v) {
            this.contentView = v;
            return this;
        }
  
        /**
         * Set the positive button resource and it's listener
         * @param positiveButtonText
         * @param listener
         * @return
         */
        public Builder setPositiveButton(int positiveButtonText,
                DialogInterface.OnClickListener listener) {
            this.positiveButtonText = (String) context
                    .getText(positiveButtonText);
            this.positiveButtonClickListener = listener;
            return this;
        }
  
        /**
         * Set the positive button text and it's listener
         * @param positiveButtonText
         * @param listener
         * @return
         */
        public Builder setPositiveButton(String positiveButtonText,
                DialogInterface.OnClickListener listener) {
            this.positiveButtonText = positiveButtonText;
            this.positiveButtonClickListener = listener;
            return this;
        }
        /**
         * Set the negative button resource and it's listener
         * @param negativeButtonText
         * @param listener
         * @return
         */
        public Builder setNegativeButton(int negativeButtonText,
                DialogInterface.OnClickListener listener) {
            this.negativeButtonText = (String) context
                    .getText(negativeButtonText);
            this.negativeButtonClickListener = listener;
            return this;
        }
  
        /**
         * Set the negative button text and it's listener
         * @param negativeButtonText
         * @param listener
         * @return
         */
        public Builder setNegativeButton(String negativeButtonText,
                DialogInterface.OnClickListener listener) {
            this.negativeButtonText = negativeButtonText;
            this.negativeButtonClickListener = listener;
            return this;
        }
  
        /**
         * Create the custom dialog
         */
        public MyDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final MyDialog dialog = new MyDialog(context, 
            		R.style.FullHeightDialog);
            View layout = inflater.inflate(R.layout.mydialog_layout, null);
            LinearLayout mydialog1_layout_lin=(LinearLayout) layout.findViewById(R.id.mydialog1_layout_lin);
    		LinearLayout mydialog2_layout_lin=(LinearLayout) layout.findViewById(R.id.mydialog2_layout_lin);
            mydialog1_layout_lin.setVisibility(8);
    		mydialog2_layout_lin.setVisibility(0);
            dialog.addContentView(layout, new LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            // set the dialog title
            ((TextView) layout.findViewById(R.id.mydialog2_layout_title)).setText(title);
            // set the confirm button
            if (positiveButtonText != null) {
                ((Button) layout.findViewById(R.id.mydialog2_layout_but1))
                        .setText(positiveButtonText);
                if (positiveButtonClickListener != null) {
                    ((Button) layout.findViewById(R.id.mydialog2_layout_but1))
                            .setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    positiveButtonClickListener.onClick(
                                            dialog, 
                                            DialogInterface.BUTTON_POSITIVE);
                                }
                            });
                }
            } else {
                // if no confirm button just set the visibility to GONE
                layout.findViewById(R.id.mydialog2_layout_but1).setVisibility(
                        View.GONE);
            }
            // set the cancel button
            if (negativeButtonText != null) {
                ((Button) layout.findViewById(R.id.mydialog2_layout_but2))
                        .setText(negativeButtonText);
                if (negativeButtonClickListener != null) {
                    ((Button) layout.findViewById(R.id.mydialog2_layout_but2))
                            .setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                	negativeButtonClickListener.onClick(
                                            dialog, 
                                            DialogInterface.BUTTON_NEGATIVE);
                                }
                            });
                }
            } else {
                // if no confirm button just set the visibility to GONE
                layout.findViewById(R.id.mydialog2_layout_but2).setVisibility(
                        View.GONE);
            }
            // set the content message
            if (message != null) {
                ((TextView) layout.findViewById(
                        R.id.mydialog2_layout_text)).setText(message);
            } else if (contentView != null) {
                // if no message set
                // add the contentView to the dialog body
                ((LinearLayout) layout.findViewById(R.id.mydialog2_layout_textlin))
                        .removeAllViews();
                ((LinearLayout) layout.findViewById(R.id.mydialog2_layout_textlin))
                        .addView(contentView, 
                                new LayoutParams(
                                        LayoutParams.WRAP_CONTENT, 
                                        LayoutParams.WRAP_CONTENT));
            }
            dialog.setContentView(layout);
            return dialog;
        }
  
    }
	public void SetMydialog1(String Dialog1_title,String Dialog1_text)
	{
		mydialog1_layout_lin.setVisibility(0);
		mydialog2_layout_lin.setVisibility(8);
		TextView mydialog1_layout_title= (TextView) mView.findViewById(R.id.mydialog1_layout_title);
		TextView mydialog1_layout_text=(TextView) mView.findViewById(R.id.mydialog1_layout_text);	
		mydialog1_layout_title.setText(Dialog1_title);
		mydialog1_layout_text.setText(Dialog1_text);
		mydialog1_layout_butt=(Button) findViewById(R.id.mydialog1_layout_butt);
		mydialog1_layout_butt.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dismiss();
			}
		});
	}
	/*public void SetMydialog2(String Dialog1_title,String Dialog1_text)
	{
		mydialog1_layout_lin.setVisibility(8);
		mydialog2_layout_lin.setVisibility(0);
		TextView mydialog2_layout_title= (TextView) mView.findViewById(R.id.mydialog2_layout_title);
		TextView mydialog2_layout_text=(TextView) mView.findViewById(R.id.mydialog2_layout_text);
		mydialog2_layout_but1=(Button) mView.findViewById(R.id.mydialog2_layout_but1);
		mydialog2_layout_but2=(Button) mView.findViewById(R.id.mydialog2_layout_but2);
		mydialog2_layout_title.setText(Dialog1_title);
		mydialog2_layout_text.setText(Dialog1_text);
	}
	public void SetListener()
	{
		mydialog2_layout_but1.setOnClickListener(new myOnclickListener());
		mydialog2_layout_but2.setOnClickListener(new myOnclickListener());
	}
	public class myOnclickListener implements android.view.View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch(v.getId())
			{
			case R.id.mydialog2_layout_but1:
			{
				clickbuttonBoolean=true;
				System.out.println("YES");
			}
			case R.id.mydialog2_layout_but2:
			{
				clickbuttonBoolean=false;
			}
			}
		}

	}
	@Override
	public void setContentView(int layoutResID) {
	}

	@Override
	public void setContentView(View view) {
	}*/

}
