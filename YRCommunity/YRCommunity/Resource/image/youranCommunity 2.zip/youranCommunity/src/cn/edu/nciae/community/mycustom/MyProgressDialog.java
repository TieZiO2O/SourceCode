
package cn.edu.nciae.community.mycustom;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.personal.R;

public class MyProgressDialog extends Dialog {
	@SuppressWarnings("unused")
	private Context context = null;
	private static MyProgressDialog customProgressDialog = null;

	public MyProgressDialog(Context context){
		super(context);
		this.context = context;
	}

	public MyProgressDialog(Context context, int theme) {
		super(context, theme);
	}

	public static MyProgressDialog createDialog(Context context){
		customProgressDialog = new MyProgressDialog(context,R.style.ProgressDialogStyle);
		customProgressDialog.setContentView(R.layout.customprogressdialog);
		customProgressDialog.getWindow().getAttributes().gravity = Gravity.CENTER;

		return customProgressDialog;
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus){

		if (customProgressDialog == null){
			return;
		}

		ImageView imageView = (ImageView) customProgressDialog.findViewById(R.id.loadingImageView);
		AnimationDrawable animationDrawable = (AnimationDrawable) imageView.getBackground();
		animationDrawable.start();
	}

	/**
	 * 
	 * [Summary]
	 *       setMessage ��ʾ����
	 * @param strMessage
	 * @return
	 *
	 */
	public MyProgressDialog setMessage(String strMessage){
		TextView tvMsg = (TextView)customProgressDialog.findViewById(R.id.id_tv_loadingmsg);

		if (tvMsg != null){
			tvMsg.setText(strMessage);
		}

		return customProgressDialog;
	}

	/**
	 *@TODO �����Զ���dialog
	 *@project youranCommunity
	 *@param context
	 *@Author Mr Rui
	 *@DATA 2015-4-24 ����5:38:50
	 */
	public static void startProgressDialog(Context context,String messzge){
		if (customProgressDialog == null){
			customProgressDialog = MyProgressDialog.createDialog(context);
			customProgressDialog.setMessage(messzge);
		}
		customProgressDialog.setCancelable(false);//���ɱ����ؼ�ȡ��
		customProgressDialog.show();
	}

	/**
	 *@TODO �ر��Զ���dialog
	 *@project youranCommunity
	 *@Author Mr Rui
	 *@DATA 2015-4-24 ����5:39:24
	 */
	public static void stopProgressDialog(){

		if (customProgressDialog != null){
			customProgressDialog.dismiss();
			customProgressDialog = null;
		}
	}

}
