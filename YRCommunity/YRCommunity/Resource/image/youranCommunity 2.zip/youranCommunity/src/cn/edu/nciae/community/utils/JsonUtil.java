package cn.edu.nciae.community.utils;



import cn.edu.nciae.community.domain.Advertisement;
import cn.edu.nciae.community.domain.Merchants;
import cn.edu.nciae.community.domain.Property;
import cn.edu.nciae.community.domain.ResultFromServer;
import cn.edu.nciae.community.domain.Users;

import com.google.gson.Gson;


public class JsonUtil {
	private static Gson gson=new Gson();
	
	public static String objectToString(Object obj){
		return gson.toJson(obj);
	}
	 
	public static ResultFromServer gsonToResultFromServer(String gsonData){
		ResultFromServer result=null;
		result=gson.fromJson(gsonData, ResultFromServer.class);
		return result;
	}  
	
	public static Users gsonToUser(String gsonData){
		Users user=null;
		user=gson.fromJson(gsonData,Users.class);
		return user;
	}
	
	public static Merchants[] gsonToShopSimple(String result){
		Merchants[] user=null;
		user=gson.fromJson(result, Merchants[].class);
		return user;
	}
	
	public static Property gsonToProperty(String gsonData){
		Property property=null;
		property=gson.fromJson(gsonData,Property.class);
		return property;
	}
	
	public static Merchants gsonToMerchants(String gsonData){
		Merchants mer=null;
		mer=gson.fromJson(gsonData,Merchants.class);
		return mer;
	}
	
	public static Advertisement[] gsonToadAdvertisements(String result){
		Advertisement[] ads=null;
		ads=gson.fromJson(result, Advertisement[].class);
		return ads;
	}
	
	

}
