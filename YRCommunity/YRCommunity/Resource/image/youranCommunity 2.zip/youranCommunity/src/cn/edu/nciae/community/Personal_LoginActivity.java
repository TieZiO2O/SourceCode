package cn.edu.nciae.community;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import cn.edu.nciae.community.app.CommunityApp;
import cn.edu.nciae.community.domain.MyOperation;
import cn.edu.nciae.community.domain.Users;
import cn.edu.nciae.community.mycustom.MyDialog;
import cn.edu.nciae.community.mycustom.MyProgressDialog;
import cn.edu.nciae.community.net.Httphelper;
import cn.edu.nciae.community.utils.CipherUtil;

import com.example.personal.R;

public class Personal_LoginActivity extends Activity {

	EditText login_username_edit, login_userpwd_edit;
	Button btLogin, btReg;
	private final Handler handler = new Handler();
	String name, pwd;

	MyDialog dialog =null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_login);
		login_username_edit = (EditText) findViewById(R.id.login_username_edit);
		login_userpwd_edit = (EditText) findViewById(R.id.login_userpwd_edit);
		btLogin = (Button) findViewById(R.id.login_login_butt);
		btReg = (Button) findViewById(R.id.login_register_but);
		dialog = new MyDialog(Personal_LoginActivity.this);
		btLogin.setOnClickListener(new click());
		btReg.setOnClickListener(new click());
		changeBack();// ���༭����˸��

	}

	class click implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.login_login_butt:
				login();// �����¼��ť���ύ��Ϣ
				break;
			case R.id.login_register_but:
				// ���ע�ᰴť
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(),
						Personal_RegisterActivity.class);
				startActivityForResult(intent, MainActivity.RequestCode_reg);
				break;
			}
		}
	}

	// ��¼
	@SuppressLint("ShowToast")
	private void login() {
		name = login_username_edit.getText().toString();// �û���
		pwd = login_userpwd_edit.getText().toString();// ����
		final String Md5Pwd=CipherUtil.generatePassword(pwd);
		if (name.length() != 0 && pwd.length() != 0) {
			if (!MyOperation.IsNetConnection(this)) {
				dialog.SetMydialog1("����", "��ȡ����ʧ��,�������������");
				dialog.show();
				return;
			}
			MyProgressDialog.startProgressDialog(Personal_LoginActivity.this, null);
			new Thread() {
				@Override
				@SuppressLint("ShowToast")
				public void run() {
					try {
						HttpPost httpPost = new HttpPost(getResources()
								.getString(R.string.base_url)
								+ "member/member_login.do");
						ArrayList<NameValuePair> nvs = new ArrayList<NameValuePair>();
						NameValuePair nameValuePair = new BasicNameValuePair(
								"username", name);
						nvs.add(nameValuePair);
						nameValuePair = new BasicNameValuePair("password", Md5Pwd);
						nvs.add(nameValuePair);
						httpPost.setEntity(new UrlEncodedFormEntity(nvs,
								"utf-8"));
						final String result = Httphelper
								.getValueFromNet(httpPost);
						if (result.indexOf("success") == 0) {
							handler.post(new Runnable() {
								@Override
								public void run() {
									String idString = result.substring(8);// ��ȡid
//									Toast.makeText(Personal_LoginActivity.this,
//											"��¼�ɹ�", 0).show();
									MyProgressDialog.stopProgressDialog();
									// ���ش洢�û�����id
									SharedPreferences sp = getSharedPreferences(
											"user", MODE_PRIVATE);
									SharedPreferences.Editor editor = sp.edit();
									editor.putString("name", name);
									editor.putString("id", idString);
									editor.putString("password", pwd);
									editor.commit();
			
									// ���õ�ǰ�û���Ϣ
									Users u = new Users();
									u.setName(name);
									u.setId(idString);
									u.setPwd(pwd);
									CommunityApp.setUser(u);// ΪUser��ֵ
									CommunityApp.setUserId(idString);
									Personal_LoginActivity.this.finish();
								}
							});
						} else if (result.indexOf("failed") == 0) {
							handler.post(new Runnable() {
								@SuppressLint("ShowToast")
								@Override
								public void run() {
									MyProgressDialog.stopProgressDialog();
									// TODO Auto-generated method stub
//									Toast.makeText(Personal_LoginActivity.this,
//											"�û������������", 0).show();
									dialog.SetMydialog1("����", "�û������������");
									dialog.show();
								}
							});
						}

						/*else if (result.indexOf("already") == 0) {
							handler.post(new Runnable() {

								@Override
								public void run() {
									MyProgressDialog.stopProgressDialog();
//									Toast.makeText(Personal_LoginActivity.this,
//											"���û����ڱ���豸��¼", 0).show();
									dialog.SetMydialog1("����", "���û����ڱ���豸��¼\n���Ǳ��˲������뼰ʱ�޸�����");
									dialog.show();
								}
							});
						}*/
					} catch (Exception e) {
						handler.post(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								MyProgressDialog.stopProgressDialog();
								Toast.makeText(getApplicationContext(),
										"���ӷ�����ʧ�ܣ����Ժ�����...", 0).show();
							}
						});
					}
				}
			}.start();
		} else {
			Toast.makeText(getApplicationContext(), "����д������Ϣ", Toast.LENGTH_SHORT).show();
			return;
		}

	}

	public void changeBack() {
		login_username_edit
				.setOnFocusChangeListener(new OnFocusChangeListener() {

					@Override
					public void onFocusChange(View v, boolean hasFocus) {
						if (hasFocus) {
							login_username_edit
									.setBackgroundResource(R.drawable.personal_reg_edit_selected);
						} else {
							login_username_edit
									.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
						}

					}
				});
		login_userpwd_edit
				.setOnFocusChangeListener(new OnFocusChangeListener() {
					@Override
					public void onFocusChange(View v, boolean hasFocus) {
						if (hasFocus) {
							login_userpwd_edit
									.setBackgroundResource(R.drawable.personal_reg_edit_selected);
						} else {
							login_userpwd_edit
									.setBackgroundResource(R.drawable.personal_reg_edit_unselected);
						}
					}
				});
	}

	@SuppressLint("ShowToast")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (requestCode == MainActivity.RequestCode_reg
				&& resultCode == Personal_RegisterActivity.RESULT_OK) {
			// ��д��ע����淵�ص��˺���Ϣ
			String name, pw;
			name = data.getStringExtra("name");
			pw = data.getStringExtra("pwd");
			login_username_edit.setText(name);
			login_userpwd_edit.setText(pw);
			Toast.makeText(getApplicationContext(), "ע��ɹ����Ͻ���½��", Toast.LENGTH_LONG).show();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	//����ͼƬ��ť�����
    public void onBackImageClick(View view)
    {
    	finish();
    }
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// ���¼����Ϸ��ذ�ť
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return true;

		} else {

			return super.onKeyDown(keyCode, event);

		}

	}
}
